// Beats: client desktop personale per Apple Music.
// Usa la build castlabs di Electron, che include Widevine (il DRM richiesto per ascoltare i brani interi).
//
// Struttura: una finestra con la nostra barra del titolo, lo sfondo dinamico e la pagina impostazioni
// (ui/shell.html), sopra cui sta la pagina music.apple.com in una vista trasparente. Le integrazioni
// di Windows leggono lo stesso stato del player.
const {
  app, BrowserWindow, WebContentsView, Menu, Tray, Notification, ipcMain,
  nativeImage, nativeTheme, shell, components, session, net, powerSaveBlocker, clipboard, dialog,
} = require('electron');
const crypto = require('crypto');
const os = require('os');
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const createSleepTimer = require('./lib/sleep-timer');
const hotkeys = require('./lib/hotkeys');
const createHistory = require('./lib/history');
const createDiscord = require('./lib/discord');
const createAirplay = require('./lib/airplay');
const firewall = require('./lib/firewall');
const { extractZip } = require('./lib/unzip');
const createLastfm = require('./lib/lastfm');
const guardMaximize = require('./lib/maximize-guard');

// Il nome dell'app si cambia solo in package.json ("productName"); lì c'è anche l'indirizzo degli aggiornamenti
const PKG = require('./package.json');
const APP_NAME = PKG.productName;
const UPDATE_URL = PKG.updateUrl || '';
// Applicazione Discord di Beats, incorporata: chi installa Beats non deve creare nulla sul portale di Discord
const discordId = () => settings.discordClientId.trim() || PKG.discordClientId || '';
const APP_ID = 'Aria.Music'; // identificativo interno per Windows: resta fisso anche se cambia il nome
const HOME_URL = 'https://music.apple.com';
const PARTITION = 'persist:applemusic'; // conserva l'accesso tra un avvio e l'altro
const BAR_HEIGHT = 44;
const ASSETS = path.join(__dirname, 'assets');
// Avviata da Beats.exe l'app è già dentro il programma; avviata da electron.exe serve passarle la cartella
const LAUNCH_ARGS = app.isPackaged ? [] : [app.getAppPath()];

// Cartella dati fissa: cambiando nome all'app non si perde l'accesso con l'ID Apple
app.setPath('userData', path.join(app.getPath('appData'), 'Mia Apple Music'));
app.setName(APP_NAME);
const IS_WIN = process.platform === 'win32';
const WINDOW_ICON = path.join(ASSETS, IS_WIN ? 'icon.ico' : 'icon.png');
if (IS_WIN) {
  app.setAppUserModelId(APP_ID);
  // Più lavoro alla scheda video e meno copie in memoria: animazioni e scorrimento più fluidi
  app.commandLine.appendSwitch('enable-gpu-rasterization');
  app.commandLine.appendSwitch('enable-zero-copy');
} else {
  if (app.setDesktopName) app.setDesktopName('beats.desktop'); // il pannello di Linux abbina la finestra all'icona installata
}
// Su Linux non sempre c'è l'area di notifica (GNOME non l'ha): chiudendo nell'icona, la finestra non si ritroverebbe più
const keepInTray = () => IS_WIN && settings.closeToTray;

const STATE_FILE = path.join(app.getPath('userData'), 'window-state.json');
const SETTINGS_FILE = path.join(app.getPath('userData'), 'settings.json');
const LOG_FILE = path.join(__dirname, 'debug.log');

// Domini che restano dentro l'app (sito musica + accesso con ID Apple)
const INTERNAL_HOSTS = [
  'music.apple.com',
  'beta.music.apple.com',
  'idmsa.apple.com',
  'appleid.apple.com',
  'authorize.music.apple.com',
  'buy.music.apple.com',
  'apple.com',
  'www.apple.com',
];

// Tavolozze per l'aurora e l'accento predefinito; i temi in ui/shell.html le combinano con le altre impostazioni
const PALETTES = {
  aria:       { name: 'Beats',     accent: '#ff6a8a', blobs: ['#ff6f61', '#c03a9b', '#4b3fd8'] },
  mezzanotte: { name: 'Mezzanotte', accent: '#6c8cff', blobs: ['#1e3a8a', '#3b2a8f', '#0e7490'] },
  tramonto:   { name: 'Tramonto',   accent: '#ffa24c', blobs: ['#ff7e3d', '#e8436b', '#8e2de2'] },
  foresta:    { name: 'Foresta',    accent: '#4cd38a', blobs: ['#0f766e', '#15803d', '#3f6212'] },
  oceano:     { name: 'Oceano',     accent: '#38c8f0', blobs: ['#0369a1', '#0891b2', '#4f46e5'] },
  ciliegia:   { name: 'Ciliegia',   accent: '#ff5d7a', blobs: ['#be123c', '#db2777', '#7c2d12'] },
  lavanda:    { name: 'Lavanda',    accent: '#b69cff', blobs: ['#a78bfa', '#f0abfc', '#93c5fd'] },
  mono:       { name: 'Monocromo',  accent: '#e5e5e5', blobs: ['#3f3f46', '#27272a', '#52525b'] },
  neon:       { name: 'Neon',       accent: '#ff2bd6', blobs: ['#ff2bd6', '#00e5ff', '#7b2bff'] },
  boreale:    { name: 'Boreale',    accent: '#3ef0b0', blobs: ['#10b981', '#06b6d4', '#7c3aed'] },
  synthwave:  { name: 'Synthwave',  accent: '#ff7ad9', blobs: ['#f72585', '#7209b7', '#ff9e00'] },
  oro:        { name: 'Oro',        accent: '#f5c451', blobs: ['#b8860b', '#7c5a12', '#3b2f1a'] },
  vulcano:    { name: 'Vulcano',    accent: '#ff5a36', blobs: ['#dc2626', '#ea580c', '#1c1917'] },
  sabbia:     { name: 'Sabbia',     accent: '#c27c4a', blobs: ['#f5d0a9', '#e9b384', '#f3e3c3'] },
  ghiaccio:   { name: 'Ghiaccio',   accent: '#2f8fe0', blobs: ['#bae6fd', '#c7d2fe', '#e0f2fe'] },
  menta:      { name: 'Menta',      accent: '#14a37f', blobs: ['#a7f3d0', '#bbf7d0', '#d9f99d'] },
  cyberpunk:  { name: 'Cyberpunk',  accent: '#fcee0a', blobs: ['#fcee0a', '#00f0ff', '#ff003c'] },
  gengy:     { name: 'Gengy',     accent: '#e8364f', blobs: ['#6a2fc4', '#3a1a80', '#b3203f'] },
};

// Ogni impostazione: valore predefinito + valori ammessi (elenco) o intervallo numerico
const SCHEMA = {
  // Aspetto
  theme:          { def: 'dark', values: ['dark', 'light', 'system'] },
  palette:        { def: 'aria', values: Object.keys(PALETTES) },
  accent:         { def: 'auto', color: true },              // 'auto' = dalla copertina
  font:           { def: 'default', values: ['default', 'segoe', 'bahnschrift', 'georgia', 'consolas'] },
  radius:         { def: 8, min: 0, max: 24 },                // angoli delle copertine (px)
  navOpacity:     { def: 38, min: 0, max: 100 },              // opacità barra laterale (%)
  zoom:           { def: 1, min: 0.6, max: 2 },
  playerOpacity:  { def: 55, min: 0, max: 100 },              // opacità del player in basso (%)
  hoverZoom:      { def: true },                              // copertine che si ingrandiscono al passaggio
  animatedCovers: { def: false },                             // copertine video di Apple (pesanti): spente = pagine più veloci
  titlebarStyle:  { def: 'gradient', values: ['gradient', 'solid', 'clear'] },
  navIcon:        { def: 'white', values: ['white', 'accent', 'muted'] },   // icone della barra laterale
  skin:           { def: 'default', values: ['default', 'cyber', 'gengy'] },         // stile dell'interfaccia (forme, caratteri, effetti)
  // Personalizzazione avanzata
  uiRadius:       { def: 22, min: 0, max: 40 },               // arrotondamento di pannelli e riquadri (px)
  shadow:         { def: 100, min: 0, max: 200 },             // intensità delle ombre (%)
  glassAlpha:     { def: 62, min: 20, max: 95 },              // opacità dei pannelli (%)
  glassBlur:      { def: 0, min: 0, max: 40 },                // vetro sfocato dietro i pannelli (0 = più leggero)
  glassShine:     { def: true },                              // riflesso e filo di luce sui pannelli trasparenti
  customFont:     { def: '', text: true },                    // qualsiasi font installato
  customCss:      { def: '', text: true, max: 20000 },        // CSS aggiunto alla pagina di Apple Music
  shellCss:       { def: '', text: true, max: 20000 },        // CSS aggiunto all'interfaccia di Beats
  // Lettore grande
  autoUpdate:     { def: true },                              // controlla gli aggiornamenti all'avvio e ogni 6 ore
  // Scorciatoie globali (anche con Beats in secondo piano)
  globalHotkeys:  { def: true },
  hk_playPause:   { def: 'Control+Alt+P', text: true },
  hk_next:        { def: 'Control+Alt+Right', text: true },
  hk_prev:        { def: 'Control+Alt+Left', text: true },
  hk_love:        { def: 'Control+Alt+L', text: true },
  hk_palette:     { def: 'Control+Alt+K', text: true },
  // Cronologia, Discord, Last.fm
  historyEnabled: { def: true },
  discordEnabled: { def: !!PKG.discordClientId },           // con l'ID incorporato funziona subito, senza configurare nulla
  discordClientId:{ def: '', text: true },                    // facoltativo: un'altra applicazione Discord al posto di quella di Beats
  lastfmEnabled:  { def: false },
  lastfmKey:      { def: '', text: true },
  lastfmSecret:   { def: '', text: true },
  lastfmSession:  { def: '', text: true },
  lastfmUser:     { def: '', text: true },
  // Altro
  visualizer:     { def: 'bars', values: ['off', 'bars', 'pulse'] },
  customBg:       { def: '', text: true },                    // file in "sfondi" nella cartella dati
  onboarded:      { def: true },
  showLyrics:     { def: true },
  liteBg:         { def: true },                              // sfondo leggero al posto di quello animato di Apple
  // Effetti
  tintStrength:   { def: 50, min: 0, max: 100 },              // velatura scura/chiara sopra lo sfondo
  vignette:       { def: true },
  grain:          { def: false },                             // grana da pellicola
  motionSpeed:    { def: 'normal', values: ['slow', 'normal', 'fast'] },
  // Audio
  audioQuality:   { def: 'high', values: ['high', 'standard'] },
  audioOutput:    { def: '', text: true },                    // nome del dispositivo; vuoto = predefinito di Windows
  autoplay:       { def: false },                             // a fine coda continua con brani simili
  fadeMs:         { def: 250, min: 0, max: 1500 },            // dissolvenza su play/pausa
  startVolume:    { def: -1, min: -1, max: 100 },             // -1 = come l'ultima volta
  pauseOnUnplug:  { def: true },
  preventSleep:   { def: true },                              // il PC non va in sospensione mentre suona
  // Sfondo
  background:     { def: 'dynamic', values: ['dynamic', 'aurora', 'solid', 'glass', 'custom'] },
  material:       { def: 'acrylic', values: ['acrylic', 'mica', 'none'] },
  blur:           { def: 90, min: 0, max: 200 },
  brightness:     { def: 62, min: 20, max: 100 },
  saturation:     { def: 170, min: 0, max: 300 },
  motion:         { def: true },
  // Barra del titolo
  showNowPlaying: { def: true },
  eqAnimation:    { def: true },
  // Integrazione con Windows
  notifications:  { def: true },
  thumbar:        { def: true },
  taskbarProgress:{ def: true },
  titleWithTrack: { def: true },
  // Finestra
  closeToTray:    { def: true },
  quietUnfocused: { def: true },   // niente animazioni né priorità alta se Beats non è in primo piano (per i giochi)
  openAtLogin:    { def: false },
  startHidden:    { def: false },
  mainOnTop:      { def: false },
  immersivePlayer:{ def: false },  // il lettore grande si apre direttamente a schermo intero senza bordi
  // Libreria
  songsView:      { def: true },   // "Brani" apre la vista di Beats, ordinabile per data di aggiunta
  songsSort:      { def: 'recent', values: ['recent', 'oldest', 'title', 'artist', 'album'] },
};
let mainWindow = null;
let appView = null;
let tray = null;
let quitting = false;
let paletteWindow = null;         // finestra della ricerca rapida (Ctrl+K)
let maxGuard = null;              // protezione dal rimbalzo della massimizzazione (lib/maximize-guard.js)
let hotkeyFailed = [];            // scorciatoie globali già occupate da altri programmi
const OVERLAYS = ['settings', 'songs', 'albums', 'artists', 'stats', 'themes', 'welcome'];
let overlay = null;               // pagina di Beats aperta sopra Apple Music (una di OVERLAYS) o nessuna
let immersive = false;            // lettore grande a schermo intero in corso
let playerOpen = false;           // lettore grande di Apple aperto (in finestra o a schermo intero)
let pendingFs = false;            // all'apertura del lettore grande, passa subito a schermo intero
let userFullScreen = false;       // schermo intero chiesto con F11: resta anche uscendo dal lettore grande
let overlayBeforeFull = null;     // pagina di Beats aperta prima del lettore grande, da riaprire all'uscita
let settings = loadSettings();
const player = { ready: false, track: null, playing: false, time: 0, duration: 0, shuffle: false, repeat: 0, volume: 0.5, accent: '#ff6a8a', devices: [] };
const page = { path: '/', loading: false, refreshing: false }; // pagina aperta in Apple Music

// Quello che i moduli in lib/ possono usare del motore
const ctx = {
  log, toast, broadcast, pageEval, updateSettings, ensureFirewall,
  get settings() { return settings; },
  userData: app.getPath('userData'),
};
const sleepTimer = createSleepTimer(ctx);
const discord = createDiscord(ctx);
const airplay = createAirplay(ctx);
const lastfm = createLastfm(ctx);
const history = createHistory(ctx, (entry) => lastfm.scrobble(entry));

// Registro diagnostico: scritto a blocchi ogni 2 secondi (non a ogni riga, per non fermare il motore)
// e ricominciato quando supera 1 MB
let logBuffer = [];
let logTimer = null;
function flushLog() {
  logTimer = null;
  if (!logBuffer.length) return;
  const text = logBuffer.join('');
  logBuffer = [];
  fs.stat(LOG_FILE, (err, st) => {
    if (!err && st.size > 1024 * 1024) fs.writeFile(LOG_FILE, text, () => {});
    else fs.appendFile(LOG_FILE, text, () => {});
  });
}
function log(line) {
  if (logBuffer.length > 500) return; // raffica di errori: basta così
  logBuffer.push(`${new Date().toISOString()} ${line}\n`);
  if (!logTimer) logTimer = setTimeout(flushLog, 2000);
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}

function validSetting(key, value) {
  const s = SCHEMA[key];
  if (!s) return undefined;
  if (s.values) return s.values.includes(value) ? value : undefined;
  if (s.color) return value === 'auto' || /^#[0-9a-f]{6}$/i.test(value) ? value : undefined;
  if (s.text) return typeof value === 'string' && value.length <= (s.max || 200) ? value : undefined;
  if (typeof s.def === 'boolean') return typeof value === 'boolean' ? value : undefined;
  if (typeof s.def === 'number') return typeof value === 'number' && isFinite(value) ? Math.min(s.max, Math.max(s.min, value)) : undefined;
  return undefined;
}

function loadSettings() {
  const raw = readJson(SETTINGS_FILE);
  if (raw.ambient === false && !raw.background) raw.background = 'solid'; // impostazione della versione precedente
  if (!raw.playerV2) raw.immersivePlayer = false; // prima il lettore grande andava sempre a schermo intero
  if (!fs.existsSync(SETTINGS_FILE)) raw.onboarded = false; // primo avvio in assoluto: schermata di benvenuto
  if (raw.hk_playPause === 'Control+Alt+Space') delete raw.hk_playPause; // spesso già usata da altri programmi
  if (!raw.discordV2 && !raw.discordClientId) delete raw.discordEnabled; // ora c'è l'app Discord incorporata: vale il nuovo predefinito
  if (!raw.glassV2 && raw.skin === 'cyber' && raw.glassAlpha === 82) raw.glassAlpha = 55; // il tema Cyberpunk ora è più trasparente
  if (!raw.discordV3 && !raw.discordClientId) delete raw.discordEnabled; // copie aggiornate che l'avevano ancora spenta
  if (raw.skin === 'gengar' || raw.skin === 'ghigno') raw.skin = 'gengy';       // il tema ha cambiato nome
  if (raw.palette === 'gengar' || raw.palette === 'ghigno') raw.palette = 'gengy';
  const out = { shortcutName: raw.shortcutName, playerV2: true, discordV2: true, discordV3: true, glassV2: true };
  for (const [key, s] of Object.entries(SCHEMA)) {
    const v = validSetting(key, raw[key]);
    out[key] = v === undefined ? s.def : v;
  }
  return out;
}

function saveSettings() {
  try { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2)); } catch {}
}

function saveWindowState() {
  if (!mainWindow) return;
  try {
    const filled = maxGuard && maxGuard.isFilled();
    const state = {
      ...((filled && maxGuard.normalBounds()) || mainWindow.getNormalBounds()),
      maximized: mainWindow.isMaximized() || filled,
      fillDisplays: maxGuard ? maxGuard.displays() : [],
    };
    fs.writeFileSync(STATE_FILE, JSON.stringify(state));
  } catch {}
}

function isInternal(url) {
  try {
    const { hostname } = new URL(url);
    return INTERNAL_HOSTS.includes(hostname) || hostname.endsWith('.music.apple.com');
  } catch {
    return false;
  }
}

// Un normale user agent di Chrome: Apple Music rifiuta i browser che non riconosce
function chromeUserAgent() {
  return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${process.versions.chrome} Safari/537.36`;
}

function icon(name, size) {
  const img = nativeImage.createFromPath(path.join(ASSETS, name));
  return size ? img.resize({ width: size, height: size }) : img;
}

const isDark = () => nativeTheme.shouldUseDarkColors;

// ---------- Colore d'accento ----------

// Dal colore di sfondo della copertina a una tinta vivace e leggibile
function accentFromArtwork(hex) {
  if (!hex || !/^[0-9a-f]{6}$/i.test(hex)) return null;
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h *= 60;
  }
  if (s < 0.12) return null; // copertine in bianco e nero: accento del tema
  return `hsl(${Math.round(h)}, ${Math.round(Math.max(s, 0.6) * 100)}%, ${isDark() ? 66 : 46}%)`;
}

function computeAccent() {
  if (settings.accent !== 'auto') return settings.accent;
  return accentFromArtwork(player.track && player.track.color) || PALETTES[settings.palette].accent;
}

// ---------- Stato condiviso con le finestre ----------

// Dati che non cambiano (o cambiano di rado): calcolati una volta, non a ogni invio dello stato
let infoCache = null;
let bgUrlCache = { name: null, url: '' };
function publicState() {
  if (!infoCache) {
    const drm = Object.values(components.status())[0];
    infoCache = { version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, widevine: drm ? drm.version : 'n/d' };
  }
  if (bgUrlCache.name !== settings.customBg) {
    const p = customBgPath();
    bgUrlCache = { name: settings.customBg, url: p ? pathToFileURL(p).href : '' };
  }
  return {
    ...player,
    page,
    settings,
    overlay,
    sideWidth: sideShown() ? shownSideWidth() : 0,
    airplayOn: airplay.active().length > 0,
    quiet: isQuiet(),
    playerOpen,
    immersive,
    discord: discord.status(),
    appName: APP_NAME,
    timer: sleepTimer.state(),
    hotkeyFailed,
    customBgUrl: bgUrlCache.url,
    dark: isDark(),
    palettes: PALETTES,
    info: infoCache,
  };
}

function broadcast() {
  const state = publicState();
  for (const win of [mainWindow, paletteWindow]) {
    if (win && !win.isDestroyed()) win.webContents.send('aria:state', state);
  }
}

// Avanzamento del brano (circa ogni secondo): solo tempo e durata, non tutto lo stato
function sendTick() {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('aria:tick', { time: player.time, duration: player.duration });
}

// Valore restituito da una funzione della pagina di Apple Music (per ricerca, album, artisti...)
function pageValue(code) {
  if (!appView) return Promise.reject(new Error('pagina non pronta'));
  return appView.webContents.executeJavaScript(code);
}

function sendData(kind, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('aria:data', { kind, ...payload });
}

// Dentro Apple Music ci si sposta senza ricaricare tutta l'app (6-8 s contro 1-1,5 s). Se non è pronta, si ricarica
function goTo(url) {
  const wc = appView && appView.webContents;
  if (!wc) return;
  // Dal lettore grande si esce: copre la pagina, e all'uscita non deve riaprirsi la vista di prima
  if (playerOpen) {
    overlayBeforeFull = null;
    leavingLibraryUntil = Date.now() + 1500;
    pageEval('window.__aria && window.__aria.closePlayer()');
  }
  // true: vale come un clic sulla pagina, così la voce resta nella cronologia del tasto Indietro
  wc.executeJavaScript(`!!(window.__aria && window.__aria.go(${JSON.stringify(url)}))`, true)
    .then((moved) => { if (!moved) wc.loadURL(url); }, () => wc.loadURL(url));
}

function pageEval(code) {
  if (appView) appView.webContents.executeJavaScript(code).catch(() => {});
}

function pageCmd(name, arg) {
  pageEval(`window.__aria && window.__aria.cmd(${JSON.stringify(name)}, ${JSON.stringify(arg ?? null)})`);
}

// Variabili CSS e carattere applicati sopra music.apple.com
function pushPageStyle() {
  player.accent = computeAccent();
  const style = {
    accent: player.accent,
    navAlpha: settings.navOpacity / 100,
    playerAlpha: settings.playerOpacity / 100,
    radius: settings.radius,
    font: settings.font,
    hoverZoom: settings.hoverZoom,
    uiRadius: settings.uiRadius,
    shadow: settings.shadow / 100,
    glassAlpha: settings.glassAlpha / 100,
    glassBlur: settings.glassBlur,
    glassShine: settings.glassShine,
    navIcon: settings.navIcon,
    customFont: settings.customFont,
    customCss: settings.customCss,
    showLyrics: settings.showLyrics,
    liteBg: settings.liteBg,
    visualizer: settings.visualizer,
    skin: settings.skin,
  };
  pageEval(`window.__aria && window.__aria.style(${JSON.stringify(style)})`);
}

function pushAudio() {
  const opts = {
    quality: settings.audioQuality,
    sinkLabel: settings.audioOutput,
    autoplay: settings.autoplay,
    fadeMs: settings.fadeMs,
    pauseOnUnplug: settings.pauseOnUnplug,
  };
  pageEval(`window.__aria && window.__aria.audio(${JSON.stringify(opts)})`);
}

// Impedisce la sospensione del PC mentre la musica suona
let sleepBlocker = null;
function updateSleepBlock() {
  const want = settings.preventSleep && player.playing;
  if (want && sleepBlocker === null) sleepBlocker = powerSaveBlocker.start('prevent-app-suspension');
  if (!want && sleepBlocker !== null) { powerSaveBlocker.stop(sleepBlocker); sleepBlocker = null; }
}

function onTrackChange(track) {
  const changed = (track && track.id) !== (player.track && player.track.id);
  player.track = track;
  pushPageStyle();
  history.onTrack(track);
  if (changed && track) {
    notifyTrack(track);
    lastfm.nowPlaying(track, player.duration);
  }
  if (changed) discord.update(player);
  updateWindowsIntegration();
}

function onPlayback(pb) {
  const wasPlaying = player.playing;
  const jumped = Math.abs((pb.time || 0) - player.time) > 5; // spostamento nel brano: Discord ricalcola il tempo
  Object.assign(player, pb);
  airplay.setVolume(player.volume);
  history.onPlayback(pb);
  sleepTimer.onPlayback(pb);
  if (wasPlaying !== player.playing || jumped) discord.update(player);
  if (wasPlaying !== player.playing) { updateThumbar(); updateSleepBlock(); }
  updateProgress();
}

ipcMain.on('aria:from-page', (event, type, payload) => {
  if (!appView || event.sender !== appView.webContents) return;
  if (type === 'apcm') { if (payload instanceof ArrayBuffer || ArrayBuffer.isView(payload)) airplay.audio(payload); return; } // arriva spesso: niente aggiornamenti dello stato
  if (type === 'airplayMenu') { showAirplayMenu(); return; }
  if (type === 'ready') {
    const first = !player.ready;
    if (first) setTimeout(() => { loadSongs(); loadAlbums(); airplay.scan(); }, 4000); // libreria e dispositivi pronti prima di aprirli
    player.ready = true;
    pushPageStyle();
    pushAudio();
    airplay.pageReady();
    if (first && settings.startVolume >= 0) pageEval(`window.__aria.setVolume(${settings.startVolume / 100})`);
  }
  else if (type === 'devices') player.devices = Array.isArray(payload) ? payload.filter((d) => typeof d === 'string').slice(0, 30) : [];
  else if (type === 'track') onTrackChange(payload);
  else if (type === 'playback') {
    const key = (p) => [p.playing, p.duration, p.shuffle, p.repeat, p.volume].join('|');
    const before = key(player);
    onPlayback(payload);
    // Solo il tempo che avanza: basta un aggiornamento leggero
    if (before === key(player)) return sendTick();
  }
  else if (type === 'fullplayer') onPlayerOpen(!!payload);
  else if (type === 'libraryNav') {
    if (payload === null) { if (SIDE_VIEWS.includes(overlay)) setOverlay(null, true); } // scelta un'altra voce della barra
    else if (settings.songsView && SIDE_VIEWS.includes(payload)) setOverlay(payload);
  }
  else if (type === 'fsToggle') setImmersive(!immersive);
  else if (type === 'fsExit') setImmersive(false);
  else if (type === 'lyricsToggle') updateSettings({ showLyrics: !settings.showLyrics });
  broadcast();
});

ipcMain.on('aria:cmd', (event, name, arg) => {
  if (mainWindow && !mainWindow.isDestroyed() && mainWindow.webContents === event.sender) runCommand(name, arg);
});

function runCommand(name, arg) {
  const wc = appView && appView.webContents;
  switch (name) {
    case 'playPause': case 'next': case 'prev': case 'seek': case 'shuffle': case 'repeat': case 'volume':
      pageCmd(name, arg); break;
    case 'openQueue': // lettore grande con la coda già aperta
      openFullPlayer(false);
      setTimeout(() => pageEval(`(() => { const b = document.getElementById('beats-queue-btn'); if (b && !b.classList.contains('on')) b.click(); })()`), 900);
      break;
    case 'back':
      if (overlay) setOverlay(null);
      // goBack e canGoBack ignorano le voci aggiunte senza un clic sulla pagina: history.back() fa sempre un passo solo
      else pageEval('history.back()');
      break;
    case 'forward': pageEval('history.forward()'); break;
    case 'home': setOverlay(null, true); goTo(HOME_URL); break;
    case 'reload': if (wc) wc.reload(); break;
    case 'refreshLibrary': refreshLibrary(); break;
    case 'openPlayer': openFullPlayer(false); break;
    case 'airplayMenu': showAirplayMenu(); break;
    case 'fullPlayer': openFullPlayer(true); break;
    case 'showMain': showMain(); break;
    case 'overlay': setOverlay(typeof arg === 'string' && OVERLAYS.includes(arg) ? arg : null); break;
    case 'timerMenu': showTimerMenu(); break;
    case 'timerCancel': sleepTimer.cancel(); break;
    case 'love': loveCurrent(); break;
    case 'palette': togglePalette(); break;
    case 'navigate': if (typeof arg === 'string' && isInternal(arg) && wc) { setOverlay(null, true); goTo(arg); } break;
    case 'playItem':
      if (arg && typeof arg.id === 'string' && ['song', 'album', 'playlist'].includes(arg.kind)) {
        pageEval(`window.__aria && window.__aria.playItem(${JSON.stringify(arg.kind)}, ${JSON.stringify(arg.id)})`);
      }
      break;
    case 'openAlbum': if (typeof arg === 'string') openLibraryItem('albums', arg); break;
    case 'openArtist': if (typeof arg === 'string') openArtist(arg); break;
    case 'openPlaylist': if (typeof arg === 'string') openLibraryItem('playlists', arg); break;
    case 'timerSet': if ([15, 30, 45, 60, 90, 120].includes(arg)) sleepTimer.set(arg); break;
    case 'timerTrack': sleepTimer.set('track'); break;
    case 'checkUpdates': checkForUpdates(true); break;
    case 'loadAlbums': loadAlbums(true); break;
    case 'stats': sendData('stats', { stats: history.stats(typeof arg === 'string' ? arg : 'month') }); break;
    case 'clearHistory': history.clear(); sendData('stats', { stats: history.stats('month') }); toast('Cronologia cancellata'); break;
    case 'lastfmConnect': lastfm.connect(); break;
    case 'lastfmFinish': lastfm.finish(); break;
    case 'lastfmDisconnect': lastfm.disconnect(); break;
    case 'pickBackground': pickBackground(); break;
    case 'finishWelcome': updateSettings({ onboarded: true }); setOverlay(null); break;
    case 'reloadSongs': loadSongs(true); break;
    case 'playSongs':
      if (arg && Array.isArray(arg.ids)) {
        const ids = arg.ids.filter((id) => typeof id === 'string').slice(0, 500);
        pageEval(`window.__aria && window.__aria.playSongs(${JSON.stringify(ids)}, ${!!arg.shuffle})`);
      }
      break;
    case 'set': if (arg && typeof arg === 'object') updateSettings(arg); break;
    case 'resetSettings': resetSettings(); break;
    case 'exportTheme': exportTheme(); break;
    case 'importTheme': importTheme(); break;
    case 'checkUpdates': checkForUpdates(true); break;
    case 'installUpdate': installUpdate(); break;
    case 'clearCache': session.fromPartition(PARTITION).clearCache().then(() => wc && wc.reload()); break;
    case 'openDataFolder': shell.openPath(app.getPath('userData')); break;
  }
}

// Ricarica la libreria scavalcando la cache, così compaiono subito i brani aggiunti da altri dispositivi
function refreshLibrary() {
  const wc = appView && appView.webContents;
  if (overlay === 'songs') return loadSongs(true);
  if (overlay === 'albums') return loadAlbums(true);
  if (overlay === 'artists') return loadArtists(true);
  if (!wc || page.refreshing) return;
  page.refreshing = true;
  broadcast();
  const done = () => setTimeout(() => { page.refreshing = false; broadcast(); }, 600);
  session.fromPartition(PARTITION).clearCache()
    .then(() => wc.reloadIgnoringCache())
    .catch(() => done());
  wc.once('did-stop-loading', done);
}

function trackPage(url) {
  const before = page.path;
  try { page.path = new URL(url).pathname; } catch {}
  // "Brani" di Apple non ordina per data: al suo posto si apre la vista Brani di Beats
  const libraryView = (page.path.match(LIBRARY_LIST) || [])[1];
  const changed = page.path !== before;
  // A indirizzo invariato conta solo se non c'è nessuna vista aperta, e non mentre si sta uscendo dalla libreria
  const uncovered = !overlay && !playerOpen && Date.now() > leavingLibraryUntil;
  if (libraryView && settings.songsView && overlay !== libraryView && (changed || uncovered)) setOverlay(libraryView);
  else broadcast();
}

// Le liste della libreria di Apple non devono mai restare scoperte: se sotto c'è una di quelle, torna la vista di Beats
function coverLibrary() {
  const libraryView = (page.path.match(LIBRARY_LIST) || [])[1];
  if (libraryView && settings.songsView && !overlay && !playerOpen) { setOverlay(libraryView); return true; }
  return false;
}

// ---------- Impostazioni ----------

function updateSettings(changes) {
  const changed = [];
  for (const [key, value] of Object.entries(changes)) {
    const v = validSetting(key, value);
    if (v !== undefined && settings[key] !== v) { settings[key] = v; changed.push(key); }
  }
  if (!changed.length) return;
  saveSettings();
  applySettings(changed);
}

function toast(text, action) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('aria:toast', { text, action });
}

// ---------- Temi da condividere ----------

// Solo le impostazioni d'aspetto: audio, finestra e libreria restano di chi riceve il tema
const THEME_KEYS = [
  'theme', 'palette', 'accent', 'font', 'radius', 'navOpacity', 'playerOpacity', 'hoverZoom', 'titlebarStyle', 'navIcon',
  'background', 'material', 'blur', 'brightness', 'saturation', 'motion', 'tintStrength', 'vignette', 'grain', 'motionSpeed',
  'uiRadius', 'shadow', 'glassAlpha', 'glassBlur', 'glassShine', 'customFont', 'customCss', 'shellCss', 'showNowPlaying', 'eqAnimation',
  'visualizer', 'skin',
];

function exportTheme() {
  const theme = { beatsTheme: 1 };
  for (const k of THEME_KEYS) theme[k] = settings[k];
  clipboard.writeText(JSON.stringify(theme, null, 2));
  toast('Tema copiato negli appunti: incollalo dove vuoi per condividerlo');
}

function importTheme() {
  try {
    const theme = JSON.parse(clipboard.readText());
    if (!theme || theme.beatsTheme !== 1) throw new Error('formato');
    const changes = {};
    for (const k of THEME_KEYS) if (k in theme) changes[k] = theme[k];
    updateSettings(changes);
    toast('Tema importato');
  } catch {
    toast('Negli appunti non c\'è un tema di Beats: copia prima il testo del tema');
  }
}

// ---------- Aggiornamenti ----------
// UPDATE_URL punta a un file latest.json: { version, zip, sha256, notes }. Lo zip contiene solo i file
// dell'app (resources\app): pochi KB, si scarica e si sostituisce senza reinstallare Electron né rifare la firma DRM.

let pendingUpdate = null;

function isNewer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
}

// raw.githubusercontent.com tiene in cache i file per alcuni minuti: per i file del repository si chiede
// all'API di GitHub, che risponde sempre con la versione appena pubblicata (60 richieste/ora: ne bastano poche)
function fetchFresh(url) {
  const m = url.match(/^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/);
  if (!m) return net.fetch(`${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`);
  const [, owner, repo, branch, file] = m;
  return net.fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${file}?ref=${branch}`, {
    headers: { Accept: 'application/vnd.github.raw', 'User-Agent': APP_NAME },
  }).then((res) => (res.ok ? res : net.fetch(`${url}?t=${Date.now()}`))); // limite superato: si ripiega sul file normale
}

async function checkForUpdates(manual = false) {
  if (!UPDATE_URL) {
    if (manual) toast('Aggiornamenti non configurati: manca "updateUrl" in package.json');
    return;
  }
  try {
    const res = await fetchFresh(UPDATE_URL);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const manifest = await res.json();
    if (!manifest.version || !manifest.zip || !manifest.sha256) throw new Error('latest.json incompleto');
    if (!isNewer(manifest.version, app.getVersion())) {
      if (manual) toast(`${APP_NAME} è aggiornata (versione ${app.getVersion()})`);
      return;
    }
    pendingUpdate = manifest;
    const text = `È disponibile ${APP_NAME} ${manifest.version}${manifest.notes ? ': ' + manifest.notes : ''}`;
    toast(text, { label: 'Installa ora', cmd: 'installUpdate' });
    if (Notification.isSupported() && !(mainWindow && mainWindow.isFocused())) {
      const n = new Notification({ title: `Aggiornamento di ${APP_NAME}`, body: text, icon: icon('icon.png') });
      n.on('click', () => { showMain(); toast(text, { label: 'Installa ora', cmd: 'installUpdate' }); });
      n.show();
    }
  } catch (e) {
    log(`aggiornamenti: ${e.message}`);
    if (manual) toast('Non riesco a controllare gli aggiornamenti in questo momento');
  }
}

async function installUpdate() {
  const m = pendingUpdate;
  if (!m) return checkForUpdates(true);
  if (!app.isPackaged) return toast('Gli aggiornamenti si installano solo nella versione installata');
  try {
    toast(`Scarico ${APP_NAME} ${m.version}…`);
    const zipUrl = new URL(m.zip, UPDATE_URL).href;
    const res = await net.fetch(zipUrl);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = Buffer.from(await res.arrayBuffer());
    const hash = crypto.createHash('sha256').update(data).digest('hex');
    if (hash.toLowerCase() !== String(m.sha256).toLowerCase()) throw new Error('file danneggiato (sha256 diverso)');

    const appDir = app.getAppPath();                       // ...\resources\app
    const tmp = fs.mkdtempSync(path.join(app.getPath('temp'), 'beats-update-'));
    const zipPath = path.join(tmp, 'update.zip');
    const newDir = path.join(tmp, 'app');
    fs.writeFileSync(zipPath, data);
    if (IS_WIN) {
      await new Promise((resolve, reject) => execFile('powershell.exe', [
        '-NoProfile', '-NonInteractive', '-Command',
        `Expand-Archive -LiteralPath '${zipPath.replace(/'/g, "''")}' -DestinationPath '${newDir.replace(/'/g, "''")}' -Force`,
      ], (err) => (err ? reject(err) : resolve())));
    } else {
      extractZip(data, newDir);
    }
    if (!fs.existsSync(path.join(newDir, 'main.js')) || !fs.existsSync(path.join(newDir, 'package.json'))) {
      throw new Error('lo zip non contiene l\'app');
    }
    // Sostituisce resources\app tenendo una copia della versione precedente
    const oldDir = `${appDir}.old`;
    fs.rmSync(oldDir, { recursive: true, force: true });
    fs.renameSync(appDir, oldDir);
    try {
      fs.cpSync(newDir, appDir, { recursive: true });
    } catch (e) {
      fs.rmSync(appDir, { recursive: true, force: true });
      fs.renameSync(oldDir, appDir);
      throw e;
    }
    fs.rmSync(tmp, { recursive: true, force: true });
    log(`aggiornata a ${m.version}`);
    quitting = true;
    app.relaunch();
    app.exit(0);
  } catch (e) {
    log(`installazione aggiornamento: ${e.message}`);
    toast(`Aggiornamento non riuscito: ${e.message}`);
  }
}

function resetSettings() {
  const changed = Object.keys(SCHEMA).filter((k) => settings[k] !== SCHEMA[k].def);
  for (const k of changed) settings[k] = SCHEMA[k].def;
  saveSettings();
  applySettings(changed);
}

// Beats non in primo piano (per esempio mentre si gioca): si fermano le animazioni e la scheda video e la finestra di
// Beats passano dopo gli altri programmi. La pagina di Apple, che riproduce la musica, resta a priorità normale.
let windowFocused = true, quietApplied = false;
const isQuiet = () => settings.quietUnfocused && !windowFocused;

function applyQuiet() {
  const quiet = isQuiet();
  if (quiet === quietApplied) return;
  quietApplied = quiet;
  pageEval(`window.__aria && window.__aria.quiet(${quiet})`);
  const level = quiet ? os.constants.priority.PRIORITY_BELOW_NORMAL : os.constants.priority.PRIORITY_NORMAL;
  const pids = app.getAppMetrics().filter((m) => m.type === 'GPU').map((m) => m.pid);
  if (mainWindow && !mainWindow.isDestroyed()) pids.push(mainWindow.webContents.getOSProcessId());
  for (const pid of pids) {
    try { os.setPriority(pid, level); } catch (e) { log(`priorità: ${e.message}`); }
  }
  broadcast();
}

function pushLibraryViews() {
  pageEval(`window.__aria && window.__aria.libraryViews(${!!settings.songsView})`);
}

function applySettings(keys) {
  const has = (...k) => k.some((x) => keys.includes(x));
  if (has('songsView')) pushLibraryViews();
  if (has('quietUnfocused')) applyQuiet();
  if (has('theme')) nativeTheme.themeSource = settings.theme; // fa scattare 'updated' qui sotto
  if (has('material')) applyMaterial();
  if (has('zoom') && appView) { appView.webContents.setZoomFactor(settings.zoom); layoutView(); }
  if (has('mainOnTop') && mainWindow) mainWindow.setAlwaysOnTop(settings.mainOnTop);
  if (has('openAtLogin', 'startHidden')) applyLoginItem();
  if (has('accent', 'palette', 'navOpacity', 'radius', 'font', 'playerOpacity', 'hoverZoom', 'uiRadius', 'shadow',
    'glassAlpha', 'glassBlur', 'glassShine', 'navIcon', 'customFont', 'customCss', 'showLyrics', 'liteBg')) pushPageStyle();
  if (has('audioQuality', 'audioOutput', 'autoplay', 'fadeMs', 'pauseOnUnplug')) pushAudio();
  if (has('preventSleep')) updateSleepBlock();
  if (keys.some((k) => k === 'globalHotkeys' || k.startsWith('hk_'))) applyHotkeys();
  if (has('discordEnabled', 'discordClientId')) { discord.configure(settings.discordEnabled, discordId()); discord.update(player); }
  if (has('visualizer', 'skin')) pushPageStyle();
  updateWindowsIntegration();
  broadcast();
}

function applyMaterial() {
  if (!mainWindow) return;
  // Il vetro acrilico e la mica esistono solo su Windows
  const material = IS_WIN ? settings.material : 'none';
  if (IS_WIN) mainWindow.setBackgroundMaterial(material);
  mainWindow.setBackgroundColor(material === 'none' ? (isDark() ? '#121218' : '#f2f2f5') : '#00000000');
}

function applyTitleBarColors() {
  if (!mainWindow) return;
  mainWindow.setTitleBarOverlay({ color: '#00000000', symbolColor: isDark() ? '#ffffff' : '#1c1c1e', height: BAR_HEIGHT });
}

nativeTheme.on('updated', () => {
  applyTitleBarColors();
  applyMaterial();
  pushPageStyle();
  broadcast();
});

// ---------- Integrazione con Windows ----------

// Pulsanti precedente / play-pausa / successivo nell'anteprima della barra delle applicazioni
function updateThumbar() {
  if (!IS_WIN || !mainWindow || mainWindow.isDestroyed()) return;
  if (!settings.thumbar) return mainWindow.setThumbarButtons([]);
  const flags = player.track ? [] : ['disabled'];
  mainWindow.setThumbarButtons([
    { tooltip: 'Precedente', icon: icon('prev.png', 16), flags, click: () => pageCmd('prev') },
    { tooltip: player.playing ? 'Pausa' : 'Riproduci', icon: icon(player.playing ? 'pause.png' : 'play.png', 16), flags, click: () => pageCmd('playPause') },
    { tooltip: 'Successivo', icon: icon('next.png', 16), flags, click: () => pageCmd('next') },
  ]);
}

// Avanzamento del brano sull'icona nella barra delle applicazioni
function updateProgress() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (!settings.taskbarProgress || !player.track || !player.duration) return mainWindow.setProgressBar(-1);
  mainWindow.setProgressBar(Math.min(1, player.time / player.duration), { mode: player.playing ? 'normal' : 'paused' });
}

function trackLabel() {
  const t = player.track;
  return t ? `${t.title}${t.artist ? ' — ' + t.artist : ''}` : '';
}

function updateWindowsIntegration() {
  const label = trackLabel();
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.setTitle(label && settings.titleWithTrack ? `${label} · ${APP_NAME}` : APP_NAME);
  }
  if (tray) {
    tray.setToolTip(label ? `${APP_NAME}\n${label}`.slice(0, 127) : APP_NAME);
    tray.setContextMenu(buildTrayMenu());
  }
  updateThumbar();
  updateProgress();
}

async function notifyTrack(track) {
  if (!settings.notifications || !Notification.isSupported()) return;
  if (mainWindow && mainWindow.isFocused()) return;
  let image;
  try {
    const res = await net.fetch(track.art.replace('600x600', '256x256'));
    image = nativeImage.createFromBuffer(Buffer.from(await res.arrayBuffer()));
  } catch {
    image = icon('icon.png');
  }
  const n = new Notification({
    title: track.title,
    body: [track.artist, track.album].filter(Boolean).join(' — '),
    icon: image,
    silent: true,
  });
  n.on('click', showMain);
  n.show();
}

function applyLoginItem() {
  if (!IS_WIN) {
    // Avvio automatico su Linux: un file nella cartella autostart dell'utente
    const file = path.join(app.getPath('appData'), 'autostart', 'beats.desktop');
    try {
      if (!settings.openAtLogin) return fs.rmSync(file, { force: true });
      fs.mkdirSync(path.dirname(file), { recursive: true });
      const exec = `"${process.execPath}"${settings.startHidden ? ' --hidden' : ''}`;
      fs.writeFileSync(file, `[Desktop Entry]\nType=Application\nName=${APP_NAME}\nExec=${exec}\nIcon=${WINDOW_ICON}\nX-GNOME-Autostart-enabled=true\n`);
    } catch (e) {
      log(`avvio automatico: ${e.message}`);
    }
    return;
  }
  app.setLoginItemSettings({
    openAtLogin: settings.openAtLogin,
    path: process.execPath,
    args: [...LAUNCH_ARGS, ...(settings.startHidden ? ['--hidden'] : [])],
  });
}

function openSettings() {
  showMain();
  setOverlay('settings');
}

function buildTrayMenu() {
  const label = trackLabel();
  return Menu.buildFromTemplate([
    { label: label || 'Nessun brano in riproduzione', enabled: false },
    { type: 'separator' },
    { label: player.playing ? 'Pausa' : 'Riproduci', enabled: !!player.track, click: () => pageCmd('playPause') },
    { label: 'Successivo', enabled: !!player.track, click: () => pageCmd('next') },
    { label: 'Precedente', enabled: !!player.track, click: () => pageCmd('prev') },
    { type: 'separator' },
    { label: `Apri ${APP_NAME}`, click: showMain },
    { label: 'Lettore a schermo intero', click: () => { showMain(); openFullPlayer(true); } },
    { label: 'Impostazioni…', click: openSettings },
    { type: 'separator' },
    { label: 'Esci', click: () => { quitting = true; app.quit(); } },
  ]);
}

function createTray() {
  tray = new Tray(icon('icon.png', 32));
  tray.setToolTip(APP_NAME);
  tray.setContextMenu(buildTrayMenu());
  tray.on('click', () => {
    if (mainWindow && mainWindow.isVisible() && mainWindow.isFocused()) mainWindow.hide();
    else showMain();
  });
}

// Comandi rapidi con clic destro sull'icona nella barra delle applicazioni
function setJumpList() {
  if (!IS_WIN) return;
  const base = { program: process.execPath, iconPath: process.execPath, iconIndex: 0 };
  const arg = (cmd) => [...LAUNCH_ARGS.map((a) => `"${a}"`), `--aria-cmd=${cmd}`].join(' ');
  app.setUserTasks([
    { ...base, title: 'Riproduci / Pausa', description: 'Riproduci o metti in pausa', arguments: arg('playPause') },
    { ...base, title: 'Brano successivo', description: 'Passa al brano successivo', arguments: arg('next') },
    { ...base, title: 'Brano precedente', description: 'Torna al brano precedente', arguments: arg('prev') },
    { ...base, title: 'Lettore a schermo intero', description: 'Apri il lettore grande', arguments: arg('fullPlayer') },
    { ...base, title: 'Impostazioni', description: `Apri le impostazioni di ${APP_NAME}`, arguments: arg('settings') },
  ]);
}

// Collegamento nel menu Start con lo stesso ID dell'app (serve anche per le notifiche)
function ensureStartMenuShortcut() {
  if (!IS_WIN) return; // su Linux il collegamento lo crea lo script di installazione
  const programs = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs');
  const options = {
    target: process.execPath,
    args: LAUNCH_ARGS.map((a) => `"${a}"`).join(' '),
    cwd: path.dirname(process.execPath),
    icon: path.join(ASSETS, 'icon.ico'),
    iconIndex: 0,
    appUserModelId: APP_ID,
    description: `${APP_NAME} — Apple Music`,
  };
  const lnk = path.join(programs, `${APP_NAME}.lnk`);
  try {
    // Se il nome dell'app è cambiato, toglie il collegamento col nome vecchio
    const old = settings.shortcutName || 'Aria';
    if (old !== APP_NAME) fs.rmSync(path.join(programs, `${old}.lnk`), { force: true });
    settings.shortcutName = APP_NAME;
    saveSettings();
    shell.writeShortcutLink(lnk, fs.existsSync(lnk) ? 'replace' : 'create', options);
  } catch (e) {
    log(`collegamento: ${e.message}`);
  }
}

// ---------- Finestre ----------

function showMain() {
  if (!mainWindow) return createMainWindow();
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

// Le pagine di Beats (impostazioni, brani) sono disegnate dalla barra del titolo: per mostrarle si nasconde Apple Music
// Liste della libreria di Apple, sostituite dalle viste di Beats. "Artisti" di Apple apre subito il primo artista
// (/library/artists/r.xxx) dentro la stessa lista, quindi conta anche quello.
const LIBRARY_LIST = /\/library\/(songs|albums|artists)(?:\/r\.[^/]+)?\/?$/;
let leavingLibraryUntil = 0;
// keepPage: chi chiama porta subito la pagina di Apple altrove (Home, un album, il lettore grande...),
// quindi non serve (e anzi disturberebbe) tornare indietro
function setOverlay(name, keepPage = false) {
  const leaving = overlay;
  overlay = name || null;
  // Brani, Album e Artisti stanno accanto alla barra laterale: il lettore grande, che la copre, si chiude prima
  if (SIDE_VIEWS.includes(overlay) && playerOpen) {
    overlayBeforeFull = null;
    pageEval('window.__aria && window.__aria.closePlayer()');
  }
  // Chiudendo Brani/Album/Artisti di Beats, la pagina di Apple sotto non deve restare sulla sua libreria:
  // torna all'ultima pagina visitata che non è una lista della libreria (o alla Home)
  const wc = appView && appView.webContents;
  // Chiudendo un'altra pagina di Beats (Impostazioni, Statistiche) sopra la libreria si torna alla vista di Beats
  if (!overlay && !keepPage && leaving && !['songs', 'albums', 'artists'].includes(leaving) && coverLibrary()) return;
  if (!overlay && !keepPage && ['songs', 'albums', 'artists'].includes(leaving) && wc && LIBRARY_LIST.test(page.path)) {
    leavingLibraryUntil = Date.now() + 1500;
    const nav = wc.navigationHistory;
    const entries = nav.getAllEntries();
    let target = -1;
    for (let i = nav.getActiveIndex() - 1; i >= 0; i--) {
      let p = '';
      try { p = new URL(entries[i].url).pathname; } catch {}
      if (entries[i].url.startsWith(HOME_URL) && !LIBRARY_LIST.test(p)) { target = i; break; }
    }
    if (target >= 0) nav.goToIndex(target);
    else goTo(HOME_URL);
  }
  if (appView) {
    appView.setVisible(!overlay || SIDE_VIEWS.includes(overlay));
    layoutView();
    pushSideView();
  }
  if (!overlay && appView && mainWindow && mainWindow.isFocused()) appView.webContents.focus();
  if (overlay === 'songs') loadSongs();
  if (overlay === 'albums') loadAlbums();
  if (overlay === 'artists') loadArtists();
  if (overlay === 'stats') sendData('stats', { stats: history.stats('month') });
  broadcast();
}

// ---------- Viste Album e Artisti (libreria per data di aggiunta) ----------

let artistsCache = null, artistsAt = 0, artistsChecking = false;
const FRESH_MS = 5 * 60 * 1000;

// Brani e album restano salvati sul disco, così si vedono subito anche all'avvio. Scaricarli tutti costa diversi
// secondi: se l'impronta della libreria (quanti sono e qual è l'ultimo aggiunto) non è cambiata non serve rifarlo
const lib = {
  songs: { list: null, head: '', at: 0, checking: false, read: 'window.__aria.librarySongs()' },
  albums: { list: null, head: '', at: 0, checking: false, read: 'window.__aria.libraryAlbums()' },
};
const libFile = (kind) => path.join(app.getPath('userData'), `cache-${kind}.json`);

async function downloadLibrary(kind) {
  const l = lib[kind];
  const head = await pageValue(`window.__aria.libraryHead(${JSON.stringify(kind)})`);
  l.list = await pageValue(l.read);
  l.head = head;
  l.at = Date.now();
  fs.writeFile(libFile(kind), JSON.stringify({ head, list: l.list }), () => {});
}

async function loadLibrary(kind, force, send) {
  const l = lib[kind];
  if (!l.list) {
    const saved = readJson(libFile(kind));
    if (Array.isArray(saved.list)) { l.list = saved.list; l.head = saved.head || ''; }
  }
  if (l.list && !force) {
    send({ list: l.list });
    if (l.checking || Date.now() - l.at < FRESH_MS) return;
    l.checking = true;
    try {
      const head = await pageValue(`window.__aria.libraryHead(${JSON.stringify(kind)})`);
      l.at = Date.now();
      if (head !== l.head) { await downloadLibrary(kind); send({ list: l.list }); }
    } catch (e) {
      log(`${kind}: ${e.message}`);
    }
    l.checking = false;
    return;
  }
  send({ loading: true });
  try {
    await downloadLibrary(kind);
    send({ list: l.list });
  } catch (e) {
    log(`${kind}: ${e.message}`);
    send({ error: true });
  }
}

function loadAlbums(force = false) {
  return loadLibrary('albums', force, (p) => sendData('albums', p.list ? { albums: p.list } : p));
}

// Apple non dà la data di aggiunta degli artisti: li ordina il brano più recente aggiunto di ciascuno
async function readArtists(force) {
  const songs = lib.songs;
  if (!songs.list) {
    const saved = readJson(libFile('songs'));
    if (Array.isArray(saved.list)) { songs.list = saved.list; songs.head = saved.head || ''; }
  }
  const stale = force || !songs.list || (await pageValue(`window.__aria.libraryHead('songs')`)) !== songs.head;
  if (stale) await downloadLibrary('songs');
  const list = await pageValue('window.__aria.libraryArtists()');
  const rank = new Map(), count = new Map(), art = new Map();
  songs.list.forEach((s, i) => {
    for (const name of String(s.artist).split(/\s*(?:,|&)\s*/)) {
      if (!rank.has(name)) { rank.set(name, i); art.set(name, s.art); }
      count.set(name, (count.get(name) || 0) + 1);
    }
  });
  return list
    .map((a) => ({ ...a, rank: rank.has(a.name) ? rank.get(a.name) : Infinity, songs: count.get(a.name) || 0, art: art.get(a.name) || '' }))
    .sort((a, b) => a.rank - b.rank);
}

function keepArtists(list) {
  artistsCache = list;
  artistsAt = Date.now();
  fs.writeFile(libFile('artists'), JSON.stringify({ list }), () => {});
  sendData('artists', { artists: list });
}

// Come brani e album: si vedono subito dal disco e, se sono vecchi di qualche minuto, si controllano senza far aspettare
async function loadArtists(force = false) {
  if (!artistsCache) {
    const saved = readJson(libFile('artists'));
    if (Array.isArray(saved.list)) artistsCache = saved.list;
  }
  if (artistsCache && !force) {
    sendData('artists', { artists: artistsCache });
    if (artistsChecking || Date.now() - artistsAt < FRESH_MS) return;
    artistsChecking = true;
    try {
      const list = await readArtists(false);
      artistsAt = Date.now();
      if (JSON.stringify(list) !== JSON.stringify(artistsCache)) keepArtists(list);
    } catch (e) {
      log(`artisti: ${e.message}`);
    }
    artistsChecking = false;
    return;
  }
  sendData('artists', { loading: true });
  try {
    keepArtists(await readArtists(force));
  } catch (e) {
    log(`artisti: ${e.message}`);
    sendData('artists', { error: true });
  }
}

// Pagina artista del catalogo (quella della libreria di Apple mostrerebbe di nuovo la sua lista di artisti)
async function openArtist(id) {
  if (!/^[\w.-]+$/.test(id)) return;
  let url = null;
  try { url = await pageValue(`window.__aria.artistUrl(${JSON.stringify(id)})`); } catch {}
  if (url && isInternal(url) && appView) {
    setOverlay(null, true);
    goTo(url);
  } else {
    toast('Questo artista non ha una pagina su Apple Music');
  }
}

function openLibraryItem(kind, id) {
  const wc = appView && appView.webContents;
  if (!wc || !/^[\w.-]+$/.test(id)) return;
  setOverlay(null, true);
  goTo(`${HOME_URL}/library/${kind}/${id}`);
}

// ---------- Timer di spegnimento, preferito ----------

function showTimerMenu() {
  if (!mainWindow) return;
  const t = sleepTimer.state();
  const items = [15, 30, 45, 60, 90, 120].map((m) => ({ label: `Tra ${m} minuti`, click: () => sleepTimer.set(m) }));
  items.push({ label: 'Alla fine di questo brano', enabled: !!player.track, click: () => sleepTimer.set('track') });
  if (t) items.push({ type: 'separator' }, { label: 'Annulla il timer', click: () => sleepTimer.cancel() });
  Menu.buildFromTemplate(items).popup({ window: mainWindow });
}

// Prima di collegarsi a un dispositivo: se manca la regola del firewall, Beats chiede il consenso e poi Windows conferma
async function ensureFirewall() {
  if (!IS_WIN || !app.isPackaged) return true; // su Linux nessuna regola; la versione di prova non è il programma installato
  return firewall.ensureRule(process.execPath, async () => {
    const { response } = await dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'AirPlay',
      message: 'Per usare AirPlay serve un permesso nel firewall di Windows',
      detail: 'HomePod e Apple TV devono poter rispondere a Beats. La regola vale solo per Beats e solo per i dispositivi della tua rete locale. Dopo "Continua" Windows chiederà la conferma.',
      buttons: ['Continua', 'Annulla'],
      defaultId: 0,
      cancelId: 1,
    });
    return response === 0;
  });
}

// AirPlay: si può scegliere più di un dispositivo; "Questo PC" scollega tutti
async function showAirplayMenu() {
  if (!mainWindow) return;
  // Con dispositivi già noti il menu si apre subito e la ricerca continua dietro; la prima volta si aspetta
  const known = airplay.list();
  const list = known.length ? known : await airplay.scan();
  if (known.length) airplay.scan();
  const on = list.some((d) => d.active);
  // Uscite di Windows: casse, cuffie e anche gli altoparlanti Bluetooth abbinati, come un Echo
  const useOutput = (label) => { airplay.stopAll(); updateSettings({ audioOutput: label }); };
  const items = [{ label: 'Questo PC (uscita predefinita)', type: 'radio', checked: !on && !settings.audioOutput, click: () => useOutput('') }];
  for (const label of player.devices) {
    items.push({ label, type: 'radio', checked: !on && settings.audioOutput === label, click: () => useOutput(label) });
  }
  items.push({ type: 'separator' });
  for (const d of list) {
    items.push({ label: `${d.name} (${d.kind})${d.connecting ? ' - collegamento...' : ''}`, type: 'checkbox', checked: d.active, click: () => airplay.toggle(d.id) });
  }
  if (!list.length) items.push({ label: 'Nessun dispositivo AirPlay trovato in rete', enabled: false });
  if (!player.devices.some((label) => /echo|alexa/i.test(label))) {
    items.push({ type: 'separator' }, { label: 'Alexa: di\' "Alexa, associa" e abbina l\'Echo nel Bluetooth di Windows', enabled: false });
  }
  Menu.buildFromTemplate(items).popup({ window: mainWindow });
}

async function loveCurrent() {
  try {
    const title = await pageValue('window.__aria.love()');
    if (title === 'nessuno') toast('Nessun brano in riproduzione');
    else if (title === 'non-catalogo') toast('Questo brano non è nel catalogo Apple Music: non si può aggiungere ai preferiti');
    else toast(`❤ ${title} aggiunto ai preferiti`);
  } catch (e) {
    log(`preferito: ${e.message}`);
    toast('Non sono riuscita ad aggiungerlo ai preferiti');
  }
}

function applyHotkeys() {
  hotkeyFailed = hotkeys.apply(settings, (action) => {
    if (action === 'palette') return togglePalette();
    if (action === 'love') return loveCurrent();
    pageCmd(action);
  });
  if (hotkeyFailed.length) log(`scorciatoie occupate: ${hotkeyFailed.join(', ')}`);
}

// ---------- Ricerca rapida (Ctrl+K) ----------

function togglePalette() {
  if (paletteWindow && !paletteWindow.isDestroyed()) {
    if (paletteWindow.isVisible()) return paletteWindow.hide();
  } else {
    paletteWindow = new BrowserWindow({
      width: 700, height: 480, show: false, frame: false, transparent: true, resizable: false,
      skipTaskbar: true, alwaysOnTop: true, parent: mainWindow || undefined, backgroundColor: '#00000000',
      webPreferences: { preload: path.join(__dirname, 'preload-ui.js'), contextIsolation: true, sandbox: true },
    });
    paletteWindow.loadFile(path.join(__dirname, 'ui', 'palette.html'));
    paletteWindow.webContents.on('did-finish-load', broadcast);
    paletteWindow.on('blur', () => { if (paletteWindow && !paletteWindow.isDestroyed()) paletteWindow.hide(); });
    paletteWindow.on('closed', () => { paletteWindow = null; });
  }
  // Al centro della finestra di Beats (o dello schermo se è nascosta)
  if (mainWindow && mainWindow.isVisible()) {
    const b = mainWindow.getBounds();
    paletteWindow.setPosition(Math.round(b.x + (b.width - 700) / 2), Math.round(b.y + Math.min(140, b.height * 0.15)));
  } else {
    paletteWindow.center();
  }
  paletteWindow.webContents.send('aria:palette-open');
  paletteWindow.show();
  paletteWindow.focus();
}

ipcMain.handle('aria:search', async (event, q) => {
  if (!paletteWindow || event.sender !== paletteWindow.webContents) return [];
  if (typeof q !== 'string' || q.trim().length < 2) return [];
  try { return await pageValue(`window.__aria.search(${JSON.stringify(q.trim().slice(0, 100))})`); } catch { return []; }
});

ipcMain.on('aria:palette-cmd', (event, name, arg) => {
  if (!paletteWindow || event.sender !== paletteWindow.webContents) return;
  paletteWindow.hide();
  if (name !== 'palette') { showMain(); runCommand(name, arg); }
});

// ---------- Sfondo personalizzato (immagine, GIF o video) ----------

const BG_DIR = path.join(app.getPath('userData'), 'sfondi');
function customBgPath() {
  if (!settings.customBg) return '';
  const p = path.join(BG_DIR, path.basename(settings.customBg));
  return fs.existsSync(p) ? p : '';
}

async function pickBackground() {
  const res = await dialog.showOpenDialog(mainWindow, {
    title: 'Scegli uno sfondo',
    filters: [{ name: 'Immagini, GIF e video', extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'mp4', 'webm'] }],
    properties: ['openFile'],
  });
  if (res.canceled || !res.filePaths[0]) return;
  const src = res.filePaths[0];
  if (fs.statSync(src).size > 200 * 1024 * 1024) return toast('File troppo grande (massimo 200 MB)');
  fs.mkdirSync(BG_DIR, { recursive: true });
  const name = `${Date.now()}${path.extname(src).toLowerCase()}`;
  fs.copyFileSync(src, path.join(BG_DIR, name));
  // Tiene solo l'ultimo sfondo scelto
  for (const f of fs.readdirSync(BG_DIR)) if (f !== name) fs.rmSync(path.join(BG_DIR, f), { force: true });
  updateSettings({ customBg: name, background: 'custom' });
}

// Brani della libreria per la vista Brani di Beats
function loadSongs(force = false) {
  if (!appView || !mainWindow) return undefined;
  return loadLibrary('songs', force, (p) => mainWindow && mainWindow.webContents.send('aria:songs', p.list ? { songs: p.list } : p));
}

// Apre il lettore grande di Apple: in finestra, oppure subito a schermo intero (fs = true).
// Se è già aperto, il pulsante schermo intero alterna finestra e schermo intero. Senza brano: schermo intero semplice.
function openFullPlayer(fs = false) {
  if (!mainWindow) return;
  if (playerOpen) return fs ? setImmersive(!immersive) : undefined;
  if (!player.track) return toggleUserFullScreen();
  // Il lettore grande vive nella pagina di Apple: si nasconde la pagina di Beats aperta e la si ripristina all'uscita
  overlayBeforeFull = overlay;
  setOverlay(null, true); // la vista si riapre all'uscita dal lettore: la pagina sotto resta dov'è
  pendingFs = fs || settings.immersivePlayer;
  pageEval(`document.querySelector('[aria-label="Apri lettore a schermo intero"], .player-lcd__artwork-overlay')?.click()`);
}

// Il lettore grande si è aperto o chiuso nella pagina (anche dai pulsanti di Apple)
function onPlayerOpen(open) {
  playerOpen = open;
  if (open) {
    if (pendingFs || settings.immersivePlayer) setImmersive(true);
    else pageEval('window.__aria && window.__aria.setFs(false)');
  } else {
    setImmersive(false);
    restoreOverlay();
  }
  pendingFs = false;
  broadcast(); // il lettore grande copre lo sfondo: inutile tenerlo in movimento
}

// Schermo intero senza bordi del lettore grande: la finestra va a schermo intero, Apple Music copre anche
// la barra del titolo e la pagina passa al layout con copertina sfumata al centro e testi a destra
function setImmersive(open) {
  if (!mainWindow || open === immersive) return;
  immersive = open;
  if (open) {
    if (!mainWindow.isFullScreen()) mainWindow.setFullScreen(true);
    if (appView && mainWindow.isFocused()) appView.webContents.focus(); // i tasti del lettore (Esc, barra spaziatrice) arrivano alla sua pagina
  } else if (!userFullScreen) {
    mainWindow.setFullScreen(false);
    // Il passaggio è asincrono e può perdersi (per esempio uscendo mentre sta ancora entrando): si ricontrolla
    setTimeout(leaveLostFullScreen, 700);
    setTimeout(leaveLostFullScreen, 1800);
  }
  pageEval(`window.__aria && window.__aria.setFs(${open})`);
  layoutView();
  broadcast(); // la finestra sotto è coperta: ferma lo sfondo in movimento
}

function leaveLostFullScreen() {
  if (mainWindow && !mainWindow.isDestroyed() && !immersive && !userFullScreen && mainWindow.isFullScreen()) {
    log('schermo intero rimasto dopo il lettore grande: esco');
    mainWindow.setFullScreen(false);
  }
}

function toggleUserFullScreen() {
  const enter = !mainWindow.isFullScreen();
  userFullScreen = enter;
  mainWindow.setFullScreen(enter);
}

// Uscendo dal lettore grande si torna dove si era (per esempio la vista Brani di Beats)
function restoreOverlay() {
  const back = overlayBeforeFull;
  overlayBeforeFull = null;
  if (back) setOverlay(back);
  else if (Date.now() > leavingLibraryUntil) coverLibrary();
}

// Brani, Album e Artisti di Beats stanno accanto alla barra laterale di Apple. La pagina resta disposta a tutta larghezza
// (viewSize), altrimenti Apple passerebbe al layout stretto, e la sua vista viene solo tagliata alla larghezza della barra
const SIDE_VIEWS = ['songs', 'albums', 'artists'];
let sideWidth = 260, emulating = false;
const sideShown = () => SIDE_VIEWS.includes(overlay) && !immersive;
const shownSideWidth = () => Math.round(sideWidth * settings.zoom);

function layoutView() {
  if (!mainWindow || !appView) return;
  const [width, height] = mainWindow.getContentSize();
  const top = immersive ? 0 : BAR_HEIGHT;
  const h = Math.max(0, height - top);
  const wc = appView.webContents;
  if (sideShown()) {
    wc.enableDeviceEmulation({
      screenPosition: 'desktop', screenSize: { width, height }, viewPosition: { x: 0, y: 0 },
      deviceScaleFactor: 0, viewSize: { width, height: h }, scale: 1,
    });
    emulating = true;
    appView.setBounds({ x: 0, y: top, width: shownSideWidth(), height: h });
  } else {
    appView.setBounds({ x: 0, y: top, width, height: h });
    if (emulating) { wc.disableDeviceEmulation(); emulating = false; }
  }
}

function pushSideView() {
  const view = sideShown() ? overlay : null;
  pageEval(`window.__aria && window.__aria.sideView(${JSON.stringify(view)})`);
  if (!view) return;
  pageValue(`document.querySelector('nav.navigation')?.getBoundingClientRect().width || 0`).then((w) => {
    if (w > 0 && Math.round(w) !== sideWidth) { sideWidth = Math.round(w); layoutView(); broadcast(); }
  }).catch(() => {});
}

function handleShortcuts(event, input) {
  if (input.type !== 'keyDown') return;
  const key = input.key.toLowerCase();
  let handled = true;
  if (input.alt && key === 'arrowleft') runCommand('back');
  else if (input.alt && key === 'arrowright') runCommand('forward');
  else if (key === 'f5') runCommand('reload');
  else if (key === 'f11') toggleUserFullScreen();
  else if (key === 'f12' && appView) appView.webContents.toggleDevTools();
  else if (input.control && input.shift && key === 'f') runCommand('fullPlayer');
  else if (input.control && key === ',') setOverlay(overlay === 'settings' ? null : 'settings');
  else if (input.control && key === 'k') togglePalette();
  else if (key === 'escape' && overlay) setOverlay(null);
  else if (key === 'escape' && !playerOpen && mainWindow.isFullScreen()) toggleUserFullScreen(); // via d'uscita sempre disponibile
  else if (input.control && (key === '=' || key === '+')) updateSettings({ zoom: Math.round((settings.zoom + 0.1) * 10) / 10 });
  else if (input.control && key === '-') updateSettings({ zoom: Math.round((settings.zoom - 0.1) * 10) / 10 });
  else if (input.control && key === '0') updateSettings({ zoom: 1 });
  else handled = false;
  if (handled) event.preventDefault();
}

function createAppView() {
  appView = new WebContentsView({
    webPreferences: {
      partition: PARTITION,
      preload: path.join(__dirname, 'preload-apple.js'),
      contextIsolation: true,
      sandbox: true,
    },
  });
  appView.setBackgroundColor('#00000000');
  const wc = appView.webContents;
  wc.setUserAgent(chromeUserAgent());
  // Copertine animate (video in loop su Home e Novità, scaricati a pezzi anche a finestra nascosta):
  // pesanti da scaricare e decodificare. Sono video senza audio ("Anull_video" nel nome del file),
  // così si possono bloccare senza toccare i videoclip veri. Bloccate, Apple mostra la copertina fissa.
  wc.session.webRequest.onBeforeRequest({ urls: ['https://mvod.itunes.apple.com/*'] }, (details, cb) => {
    const cancel = !settings.animatedCovers && /Anull_video|_video_gr\d+/i.test(details.url) && !/audio/i.test(details.url);
    cb({ cancel });
  });

  const css = fs.readFileSync(path.join(__dirname, 'inject', 'page.css'), 'utf8');
  const js = fs.readFileSync(path.join(__dirname, 'inject', 'page.js'), 'utf8');
  wc.on('dom-ready', () => {
    // una pagina appena caricata non ha il lettore grande aperto
    setImmersive(false);
    playerOpen = false;
    wc.insertCSS(css).catch(() => {});
    wc.executeJavaScript(js).then(() => { pushPageStyle(); pushLibraryViews(); pushSideView(); pageEval(`window.__aria && window.__aria.quiet(${isQuiet()})`); }).catch((e) => log(`inject: ${e.message}`));
    wc.setZoomFactor(settings.zoom);
  });

  // Popup di accesso Apple dentro l'app, tutto il resto nel browser predefinito
  wc.setWindowOpenHandler(({ url }) => {
    if (isInternal(url)) {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          width: 520,
          height: 720,
          autoHideMenuBar: true,
          backgroundColor: '#1f1f1f',
          icon: WINDOW_ICON,
          webPreferences: { partition: PARTITION, contextIsolation: true, sandbox: true },
        },
      };
    }
    shell.openExternal(url);
    return { action: 'deny' };
  });
  wc.on('will-navigate', (event, url) => {
    if (!isInternal(url)) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });
  wc.on('before-input-event', handleShortcuts);
  wc.on('did-navigate', (_e, url) => trackPage(url));
  wc.on('did-navigate-in-page', (_e, url) => trackPage(url));
  wc.on('did-start-loading', () => { page.loading = true; broadcast(); });
  wc.on('did-stop-loading', () => { page.loading = false; broadcast(); });

  // Registro diagnostico. I messaggi della console di Apple (centinaia al minuto) si leggono solo se
  // si avvia con BEATS_DEBUG=1, per non far lavorare il motore a vuoto
  if (process.env.BEATS_DEBUG) {
    wc.on('console-message', (event) => {
      if (event.level === 'error') log(`console ${event.level}: ${event.message}`);
    });
  }
  wc.on('render-process-gone', (_e, details) => log(`pagina chiusa inaspettatamente: ${details.reason}`));
  wc.on('unresponsive', () => log('pagina bloccata (non risponde)'));

  wc.loadURL(HOME_URL);
}

function createMainWindow({ hidden = false } = {}) {
  const state = readJson(STATE_FILE);
  mainWindow = new BrowserWindow({
    x: state.x,
    y: state.y,
    width: state.width || 1360,
    height: state.height || 860,
    minWidth: 900,
    minHeight: 600,
    show: false,
    title: APP_NAME,
    icon: WINDOW_ICON,
    backgroundColor: '#00000000',
    ...(IS_WIN ? { backgroundMaterial: settings.material } : {}), // vetro di Windows 11 dietro lo sfondo
    alwaysOnTop: settings.mainOnTop,
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#00000000', symbolColor: isDark() ? '#ffffff' : '#1c1c1e', height: BAR_HEIGHT },
    webPreferences: {
      preload: path.join(__dirname, 'preload-ui.js'),
      contextIsolation: true,
      sandbox: true,
    },
  });
  mainWindow.setMenuBarVisibility(false);
  applyMaterial();
  maxGuard = guardMaximize(mainWindow, { log, known: state.fillDisplays || [], onLearn: saveWindowState });
  if (state.maximized) maxGuard.maximize();

  mainWindow.loadFile(path.join(__dirname, 'ui', 'shell.html'));
  mainWindow.webContents.on('did-finish-load', broadcast);
  mainWindow.webContents.on('before-input-event', handleShortcuts);
  mainWindow.once('ready-to-show', () => {
    if (!hidden) mainWindow.show();
    windowFocused = mainWindow.isFocused(); // avviata dietro a un gioco non riceve mai l'avviso di "perso il primo piano"
    applyQuiet();
  });

  createAppView();
  mainWindow.contentView.addChildView(appView);
  layoutView();
  // Anche il fuoco spostato tra le viste interne fa scattare "focus": conta solo se la finestra è davvero in primo piano
  mainWindow.on('focus', () => { windowFocused = mainWindow.isFocused(); applyQuiet(); });
  mainWindow.on('blur', () => { windowFocused = false; applyQuiet(); });
  mainWindow.on('resize', layoutView);
  mainWindow.on('maximize', layoutView);
  mainWindow.on('unmaximize', layoutView);
  mainWindow.on('enter-full-screen', layoutView);
  mainWindow.on('leave-full-screen', () => {
    // Uscita dallo schermo intero (F11) col lettore grande: torna al lettore in finestra
    userFullScreen = false;
    if (immersive) {
      immersive = false;
      pageEval('window.__aria && window.__aria.setFs(false)');
    }
    layoutView();
  });

  mainWindow.on('close', (event) => {
    saveWindowState();
    if (keepInTray() && !quitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
  mainWindow.on('closed', () => { mainWindow = null; appView = null; });

  updateWindowsIntegration();
}

// ---------- Avvio ----------

function commandFromArgv(argv) {
  const arg = argv.find((a) => a.startsWith('--aria-cmd='));
  return arg ? arg.split('=')[1] : null;
}

function runArgvCommand(cmd) {
  if (cmd === 'settings') openSettings();
  else if (['playPause', 'next', 'prev', 'fullPlayer'].includes(cmd)) runCommand(cmd);
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    const cmd = commandFromArgv(argv);
    if (cmd) runArgvCommand(cmd);
    else showMain();
  });

  app.whenReady().then(async () => {
    // Aspetta che il modulo Widevine sia scaricato e pronto (al primo avvio può richiedere qualche secondo)
    // Se il modulo non arriva l'app si apre lo stesso: un errore nel registro è meglio di una finestra che non compare
    try {
      await components.whenReady();
    } catch (e) {
      log(`DRM non pronto: ${e.message}`);
    }
    log(`avvio: electron ${process.versions.electron}, DRM ${JSON.stringify(components.status())}`);

    nativeTheme.themeSource = settings.theme;
    session.fromPartition(PARTITION).setUserAgent(chromeUserAgent());
    Menu.setApplicationMenu(null);
    ensureStartMenuShortcut();
    setJumpList();
    applyLoginItem();
    try {
      createTray();
    } catch (e) {
      log(`icona di notifica: ${e.message}`); // senza area di notifica l'app funziona lo stesso
    }
    createMainWindow({ hidden: process.argv.includes('--hidden') });
    applyHotkeys();
    discord.configure(settings.discordEnabled, discordId());
    if (!settings.onboarded) setOverlay('welcome');
    if (settings.autoUpdate && app.isPackaged) {
      setTimeout(() => checkForUpdates(false), 15000);
      setInterval(() => checkForUpdates(false), 6 * 60 * 60 * 1000);
    }
  });

  app.on('before-quit', () => {
    quitting = true;
    history.finalize(); // salva anche il brano in corso
    hotkeys.clear();
    discord.disconnect();
    airplay.shutdown();
  });
  app.on('window-all-closed', () => { if (quitting || !keepInTray()) app.quit(); });
}
