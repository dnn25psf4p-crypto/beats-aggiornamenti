// Iniettato in music.apple.com: segue MusicKit e riceve i comandi dall'app.
(() => {
  if (window.__aria) return;
  const send = (type, payload) => window.ariaBridge && window.ariaBridge.send(type, payload);
  let mk = null;

  const artUrl = (item, size) => {
    const art = item.artwork || (item.attributes && item.attributes.artwork);
    if (!art || !art.url) return null;
    return art.url.replace('{w}', size).replace('{h}', size).replace('{f}', 'jpg').replace('{c}', '');
  };

  const track = () => {
    const it = mk.nowPlayingItem;
    if (!it) return null;
    const attrs = it.attributes || {};
    const art = attrs.artwork || it.artwork || {};
    return {
      id: it.id,
      title: it.title || attrs.name || '',
      artist: it.artistName || attrs.artistName || '',
      album: it.albumName || attrs.albumName || '',
      art: artUrl(it, 600),
      color: art.bgColor || null,
      genre: (attrs.genreNames && attrs.genreNames.find((g) => g !== 'Musica' && g !== 'Music')) || (attrs.genreNames || [])[0] || '',
    };
  };

  const playback = () => ({
    playing: !!mk.isPlaying,
    time: mk.currentPlaybackTime || 0,
    duration: mk.currentPlaybackDuration || 0,
    shuffle: !!mk.shuffleMode,
    repeat: mk.repeatMode || 0,          // 0 no, 1 un brano, 2 tutti
    volume: Math.round((mk.volume || 0) * 100) / 100,
  });

  // ---------- Audio ----------
  const audio = { fadeMs: 0, sinkLabel: '', pauseOnUnplug: true };
  let fadeState = null; // dissolvenza del timer di spegnimento in corso
  const styleCache = {}; // ultime variabili CSS scritte su :root
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Il lettore audio di MusicKit non è nella pagina: lo si intercetta quando parte, per scegliere l'uscita
  const mediaEls = new Set();
  const origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function (...args) {
    if (this.tagName === 'AUDIO' || !this.muted) { mediaEls.add(this); applySink(this); }
    if (ap.wanted && this.tagName === 'AUDIO') airplayRoute();
    return origPlay.apply(this, args);
  };

  // AirPlay: l'audio del lettore passa da qui e va all'app a blocchi di 0,1 s (PCM 16 bit stereo). Una volta
  // agganciato, il lettore suona solo attraverso questo grafo: a PC va collegato alle casse, in AirPlay no.
  // Il segnale arriva già abbassato dal volume del lettore: il guadagno lo riporta pieno, perché il volume
  // lo applica il dispositivo
  const AP_WORKLET = `registerProcessor('beats-ap', class extends AudioWorkletProcessor {
    constructor() { super(); this.out = new Int16Array(8820); this.n = 0; }
    process(inputs) {
      const ch = inputs[0], l = ch[0], r = ch[1] || l;
      for (let i = 0; i < 128; i++) {
        const a = l ? l[i] : 0, b = r ? r[i] : 0;
        this.out[this.n++] = Math.max(-1, Math.min(1, a)) * 32767;
        this.out[this.n++] = Math.max(-1, Math.min(1, b)) * 32767;
        if (this.n === this.out.length) { const copy = this.out.slice(0); this.port.postMessage(copy.buffer, [copy.buffer]); this.n = 0; }
      }
      return true;
    }
  });`;
  const ap = { wanted: false, ctx: null, src: null, gain: null, node: null, loading: null };
  // Il dispositivo suona circa 1,1 s dopo il lettore (il suo margine più il viaggio dei blocchi): mentre AirPlay
  // è attivo il lettore dichiara il tempo di ciò che si sente, così testo e barra di avanzamento restano a tempo.
  // Una richiesta di salto all'inizio del brano resta all'inizio, altrimenti se ne perderebbe il primo secondo
  const AP_DELAY = 1.1;
  const mediaTime = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'currentTime');
  function apShiftClock(el, on) {
    if (!on) { delete el.currentTime; return; }
    Object.defineProperty(el, 'currentTime', {
      configurable: true,
      get() { return Math.max(0, mediaTime.get.call(this) - AP_DELAY); },
      set(v) { mediaTime.set.call(this, v < AP_DELAY ? v : v + AP_DELAY); },
    });
  }
  const apGain = () => {
    if (!ap.gain || !mk) return;
    const v = mk.volume;
    ap.gain.gain.setTargetAtTime(v > 0.005 ? 1 / v : 0, ap.ctx.currentTime, 0.01);
  };
  async function airplayRoute() {
    const el = document.getElementById('apple-music-player');
    if (!el) return; // il lettore nasce al primo brano: si riprova quando parte
    if (!ap.src) {
      if (!ap.wanted) return;
      if (!ap.loading) {
        ap.loading = (async () => {
          ap.ctx = new AudioContext({ sampleRate: 44100, latencyHint: 'playback' });
          const url = URL.createObjectURL(new Blob([AP_WORKLET], { type: 'text/javascript' }));
          await ap.ctx.audioWorklet.addModule(url);
          URL.revokeObjectURL(url);
          ap.node = new AudioWorkletNode(ap.ctx, 'beats-ap', { numberOfOutputs: 0 });
          ap.node.port.onmessage = (e) => { if (ap.wanted) send('apcm', e.data); };
          ap.gain = ap.ctx.createGain();
          ap.gain.connect(ap.node);
          ap.src = ap.ctx.createMediaElementSource(el);
        })();
      }
      await ap.loading;
    }
    try { await ap.ctx.resume(); } catch {}
    apShiftClock(el, ap.wanted);
    ap.src.disconnect();
    if (ap.wanted) { apGain(); ap.src.connect(ap.gain); }
    else {
      ap.src.connect(ap.ctx.destination);
      apApplySink();
    }
  }
  // Una volta agganciato il lettore suona attraverso il grafo: l'uscita scelta va impostata qui, non sul lettore
  async function apApplySink() {
    if (!ap.src || ap.wanted || !ap.ctx.setSinkId) return;
    try { await ap.ctx.setSinkId(await sinkId()); } catch {}
  }
  // '' = uscita predefinita di Windows. L'id del dispositivo scelto si cerca una volta sola
  // (si ricalcola quando cambia la scelta o i dispositivi collegati)
  let sinkCache = null; // { label, id }
  async function sinkId() {
    if (!audio.sinkLabel) return '';
    if (sinkCache && sinkCache.label === audio.sinkLabel) return sinkCache.id;
    const devs = await navigator.mediaDevices.enumerateDevices();
    const d = devs.find((x) => x.kind === 'audiooutput' && x.label === audio.sinkLabel);
    sinkCache = { label: audio.sinkLabel, id: d ? d.deviceId : '' };
    return sinkCache.id;
  }
  async function applySink(el) {
    // Uscita predefinita e mai cambiata: niente da fare (prima si reimpostava a ogni brano, rallentando l'avvio)
    if (!audio.sinkLabel && !el.sinkId) return;
    try {
      const id = await sinkId();
      if (el.sinkId !== id) await el.setSinkId(id);
    } catch {}
  }
  async function sendDevices() {
    try {
      const devs = await navigator.mediaDevices.enumerateDevices();
      const outs = devs.filter((d) => d.kind === 'audiooutput' && d.deviceId !== 'default' && d.deviceId !== 'communications').map((d) => d.label);
      send('devices', outs);
      return outs;
    } catch { return []; }
  }
  // Cuffie scollegate: se spariscono uscite audio durante la riproduzione, pausa
  let outputCount = null;
  navigator.mediaDevices.addEventListener('devicechange', async () => {
    sinkCache = null;
    const outs = await sendDevices();
    if (audio.pauseOnUnplug && mk && mk.isPlaying && outputCount !== null && outs.length < outputCount) mk.pause();
    outputCount = outs.length;
    mediaEls.forEach(applySink);
    apApplySink();
  });

  // Dissolvenza del volume su play/pausa comandati da Beats
  async function fadeTo(target, ms) {
    const from = mk.volume, steps = Math.max(1, Math.round(ms / 25));
    for (let i = 1; i <= steps; i++) { mk.volume = from + (target - from) * (i / steps); await sleep(ms / steps); }
  }
  async function playPause() {
    if (!audio.fadeMs) return mk.isPlaying ? mk.pause() : mk.play();
    if (mk.isPlaying) {
      const vol = mk.volume;
      await fadeTo(0, audio.fadeMs);
      await mk.pause();
      mk.volume = vol;
    } else {
      const vol = mk.volume;
      mk.volume = 0;
      await mk.play();
      await fadeTo(vol, audio.fadeMs);
    }
  }

  // Con le viste di Beats attive, Brani/Album/Artisti si aprono al clic senza far caricare prima la lista di Apple
  let libraryViews = false;
  let quietOn = false;
  // Si fermano solo le animazioni continue: quelle di ingresso, fermate a metà, lascerebbero titoli e copertine invisibili
  const pausedLoops = new Set();
  function pauseLoops() {
    if (!quietOn) {
      for (const a of pausedLoops) a.play();
      pausedLoops.clear();
      return;
    }
    for (const a of document.getAnimations()) {
      if (a.playState === 'running' && a.effect && a.effect.getComputedTiming().iterations === Infinity) {
        a.pause();
        pausedLoops.add(a);
      }
    }
  }

  window.__aria = {
    // Sposta Apple Music su un indirizzo senza ricaricarla: il suo router, davanti a una voce di cronologia che non
    // conosce, carica la pagina dall'indirizzo. Se l'app non è ancora in piedi risponde false e ricarica chi ha chiamato
    go(url) {
      const u = new URL(url, location.href);
      if (u.origin !== location.origin || !document.querySelector('nav a[href]')) return false;
      if (u.pathname === '/') {
        const home = document.querySelector('nav a[href$="/home"]');
        if (!home) return false;
        if (!location.pathname.endsWith('/home')) home.click();
        return true;
      }
      if (u.pathname !== location.pathname) {
        const state = { id: `beats-${Date.now()}` };
        history.pushState(state, '', u.pathname + u.search);
        dispatchEvent(new PopStateEvent('popstate', { state }));
      }
      return true;
    },
    libraryViews(on) { libraryViews = !!on; },
    // Beats non in primo piano: ferme le animazioni della pagina, le copertine video e le barre del lettore; la musica no
    quiet(on) {
      quietOn = !!on;
      window.__beatsMaxFps = quietOn ? 12 : 0;
      document.documentElement.classList.toggle('beats-quiet', quietOn);
      pauseLoops();
      for (const v of document.querySelectorAll('main video')) { if (quietOn) v.pause(); else v.play().catch(() => {}); }
      playerLoops();
    },
    // Una vista di Beats è aperta accanto alla barra laterale: la barra segna quella e il resto della pagina si ferma
    sideView(view) {
      document.documentElement.classList.toggle('beats-side-view', !!view);
      document.querySelector('nav a.beats-side-active')?.classList.remove('beats-side-active');
      if (view) document.querySelector(`nav a[href$="/library/${view}"]`)?.classList.add('beats-side-active');
    },
    closePlayer() {
      (document.querySelector('[data-testid="lyrics-fullscreen-modal"] .close-button, [data-testid="lyrics-fullscreen-modal"] button[aria-label*="Chiudi"]')
        || (document.documentElement.classList.contains('beats-mini-open') ? document.querySelector('#now-playing-dialog [data-testid="sliding-modal-collapse"]') : null))?.click();
    },
    audio(opts) {
      Object.assign(audio, { fadeMs: opts.fadeMs, sinkLabel: opts.sinkLabel, pauseOnUnplug: opts.pauseOnUnplug });
      if (!mk) return;
      mk.bitrate = opts.quality === 'standard' ? MusicKit.PlaybackBitrate.STANDARD : MusicKit.PlaybackBitrate.HIGH;
      try { mk.autoplayEnabled = !!opts.autoplay; } catch {}
      mediaEls.forEach(applySink);
      apApplySink();
    },
    setVolume(v) { if (mk) mk.volume = v; },
    airplay(on) {
      if (ap.wanted === on) return;
      ap.wanted = on;
      document.getElementById('beats-airplay-btn')?.classList.toggle('on', on);
      airplayRoute();
    },

    // Timer di spegnimento: abbassa piano il volume, mette in pausa e rimette il volume di prima
    async fadeOutAndPause(ms) {
      if (!mk || fadeState) return;
      fadeState = { vol: mk.volume, cancelled: false };
      const steps = Math.max(1, Math.round(ms / 100));
      for (let i = 1; i <= steps && !fadeState.cancelled; i++) {
        mk.volume = fadeState.vol * (1 - i / steps);
        await sleep(ms / steps);
      }
      if (!fadeState.cancelled) await mk.pause();
      mk.volume = fadeState.vol;
      fadeState = null;
    },
    cancelFade() { if (fadeState) fadeState.cancelled = true; },

    // Preferito ("cuore") per il brano in ascolto
    async love() {
      const it = mk && mk.nowPlayingItem;
      if (!it) return 'nessuno';
      const pp = (it.attributes && it.attributes.playParams) || it.playParams || {};
      const id = pp.catalogId || (String(it.id).startsWith('i.') ? null : it.id);
      if (!id) return 'non-catalogo';
      try {
        await mk.api.music(`/v1/me/favorites`, { 'ids[songs]': id }, { fetchOptions: { method: 'POST' } });
      } catch {
        await mk.api.music(`/v1/me/ratings/songs/${id}`, {}, {
          fetchOptions: { method: 'PUT', body: JSON.stringify({ type: 'rating', attributes: { value: 1 } }) },
        });
      }
      return it.title;
    },

    // Ricerca rapida: catalogo Apple Music + la tua libreria
    async search(q) {
      const sf = mk.storefrontId || 'it';
      const pick = (r) => (r.status === 'fulfilled' ? r.value.data.results || {} : {});
      const [cat, lib] = await Promise.allSettled([
        mk.api.music(`/v1/catalog/${sf}/search`, { term: q, types: 'songs,albums,artists,playlists', limit: 4 }),
        mk.api.music('/v1/me/library/search', { term: q, types: 'library-songs,library-albums,library-playlists', limit: 3 }),
      ]);
      const out = [];
      const add = (group, kind, label, source) => {
        for (const d of (group && group.data) || []) {
          const a = d.attributes || {};
          out.push({
            kind, label, source, id: d.id, type: d.type,
            title: a.name || '',
            subtitle: a.artistName || a.curatorName || (kind === 'artist' ? 'Artista' : ''),
            art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 96).replace('{h}', 96).replace('{f}', 'jpg') : '',
            url: a.url || '',
          });
        }
      };
      const l = pick(lib), c = pick(cat);
      add(l['library-songs'], 'song', 'Brano', 'Libreria');
      add(l['library-albums'], 'album', 'Album', 'Libreria');
      add(l['library-playlists'], 'playlist', 'Playlist', 'Libreria');
      add(c.songs, 'song', 'Brano', 'Apple Music');
      add(c.albums, 'album', 'Album', 'Apple Music');
      add(c.artists, 'artist', 'Artista', 'Apple Music');
      add(c.playlists, 'playlist', 'Playlist', 'Apple Music');
      return out;
    },
    async playItem(kind, id) {
      const key = { song: 'song', album: 'album', playlist: 'playlist' }[kind];
      if (key) await mk.setQueue({ [key]: id, startPlaying: true });
    },

    // Libreria per le viste di Beats: album dal più recente aggiunto, artisti con i loro id
    async libraryAlbums() {
      const page = (offset) => mk.api.music('/v1/me/library/albums', { limit: 100, offset, sort: '-dateAdded' });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      return pages.flatMap((p) => p.data.data).map((d) => {
        const a = d.attributes || {};
        return {
          id: d.id, title: a.name || '', artist: a.artistName || '', count: a.trackCount || 0,
          art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 300).replace('{h}', 300).replace('{f}', 'jpg') : '',
        };
      });
    },
    async artistUrl(id) {
      const r = await mk.api.music(`/v1/me/library/artists/${id}`, { include: 'catalog' });
      const d = r.data.data[0];
      const cat = d && d.relationships && d.relationships.catalog && d.relationships.catalog.data[0];
      return (cat && cat.attributes && cat.attributes.url) || null;
    },
    async libraryArtists() {
      const page = (offset) => mk.api.music('/v1/me/library/artists', { limit: 100, offset });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      return pages.flatMap((p) => p.data.data).map((d) => ({ id: d.id, name: (d.attributes && d.attributes.name) || '' }));
    },
    // Layout del lettore grande a schermo intero (copertina sfumata al centro, testi a destra)
    setFs(on) {
      fsOn = !!on;
      document.documentElement.classList.toggle('beats-fs', fsOn);
      paintFsButton();
      requestAnimationFrame(() => requestAnimationFrame(placeQueueButton));
      setTimeout(placeQueueButton, 500);
    },
    outputs() { return [...mediaEls].map((e) => `${e.tagName}:${e.sinkId || 'default'}`); }, // diagnostica
    cmd(name, arg) {
      if (!mk) return;
      switch (name) {
        case 'playPause': playPause(); break;
        case 'next': mk.skipToNextItem(); break;
        case 'prev': mk.currentPlaybackTime > 3 ? mk.seekToTime(0) : mk.skipToPreviousItem(); break;
        case 'seek': if (mk.currentPlaybackDuration) mk.seekToTime(arg * mk.currentPlaybackDuration); break;
        case 'shuffle': mk.shuffleMode = mk.shuffleMode ? 0 : 1; send('playback', playback()); break;
        case 'repeat': mk.repeatMode = ((mk.repeatMode || 0) + 1) % 3; send('playback', playback()); break;
        case 'volume': mk.volume = Math.max(0, Math.min(1, Number(arg) || 0)); break;
      }
    },
    // Tutti i brani della libreria, dal più recente aggiunto (ordine fornito dal server di Apple)
    async librarySongs() {
      const page = (offset) => mk.api.music('/v1/me/library/songs', { limit: 100, offset, sort: '-dateAdded' });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      const songs = [];
      for (const p of pages) {
        for (const s of p.data.data) {
          const a = s.attributes || {};
          songs.push({
            id: s.id,
            title: a.name || '',
            artist: a.artistName || '',
            album: a.albumName || '',
            ms: a.durationInMillis || 0,
            art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 80).replace('{h}', 80).replace('{f}', 'jpg') : null,
          });
        }
      }
      return songs;
    },
    // Impronta della libreria: se non cambia, i brani salvati sul disco sono ancora giusti
    async libraryHead(kind) {
      const r = await mk.api.music(`/v1/me/library/${kind}`, { limit: 1, sort: '-dateAdded' });
      const first = r.data.data[0];
      return `${(r.data.meta && r.data.meta.total) || 0}|${first ? first.id : ''}`;
    },
    // Parte subito con il brano scelto: chiedere ad Apple i dati di tutta la coda prima di suonare costa più di
    // un secondo. Gli altri si aggiungono dopo, a musica partita (se nel frattempo se ne sceglie un altro, niente)
    async playSongs(ids, shuffle) {
      const gen = ++playGen;
      const list = ids.slice();
      if (shuffle) for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
      mk.shuffleMode = shuffle ? 1 : 0;
      await mk.setQueue({ songs: list.slice(0, 1), startPlaying: true });
      if (list.length < 2) return;
      await sleep(1500);
      if (gen === playGen) await mk.playLater({ songs: list.slice(1) });
    },
    // Ogni modifica a :root ricalcola lo stile di tutta la pagina di Apple: si scrive solo ciò che è cambiato
    style(s) {
      const root = document.documentElement;
      const set = (k, v) => { v = String(v); if (styleCache[k] !== v) { styleCache[k] = v; root.style.setProperty(k, v); } };
      const data = (k, v) => { if (root.dataset[k] !== v) root.dataset[k] = v; };
      set('--aria-accent', s.accent);
      vizAccent = s.accent;
      set('--aria-nav-alpha', s.navAlpha);
      set('--aria-player-alpha', s.playerAlpha);
      set('--aria-radius', s.radius + 'px');
      set('--beats-radius', s.uiRadius + 'px');
      set('--beats-shadow', s.shadow);
      set('--beats-glass-alpha', s.glassAlpha);
      set('--beats-glass-blur', s.glassBlur + 'px');
      const icon = { white: ['#fff', '#1c1c1e'], accent: [s.accent, s.accent], muted: ['rgba(255,255,255,0.55)', 'rgba(0,0,0,0.5)'] }[s.navIcon];
      set('--beats-nav-icon', icon[0]);
      set('--beats-nav-icon-light', icon[1]);
      data('ariaFont', s.font);
      data('ariaHoverZoom', s.hoverZoom ? 'on' : 'off');
      data('viz', s.visualizer);
      playerLoops();
      root.classList.toggle('beats-glass', s.glassBlur > 0);
      root.classList.toggle('beats-shine', s.glassShine);
      root.classList.toggle('beats-lite-bg', s.liteBg);
      root.classList.toggle('beats-skin-cyber', s.skin === 'cyber');
      root.classList.toggle('beats-skin-gengy', s.skin === 'gengy');
      if (s.customFont) set('--beats-custom-font', `"${s.customFont.replace(/["\\]/g, '')}"`);
      root.classList.toggle('beats-custom-font', !!s.customFont);
      if (root.classList.contains('beats-nolyrics') === s.showLyrics) {
        root.classList.toggle('beats-nolyrics', !s.showLyrics);
        requestAnimationFrame(() => requestAnimationFrame(placeQueueButton)); // la colonna dei comandi si sposta
      }
      if (lyricsOn !== s.showLyrics || !document.querySelector('#beats-lyrics-btn svg')) paintLyricsButton(s.showLyrics);
      if (window.__beatsCovers !== s.animatedCovers) {
        window.__beatsCovers = s.animatedCovers;
        try { localStorage.setItem('beats-covers', s.animatedCovers ? '1' : '0'); } catch {}
        if (s.animatedCovers) for (const v of document.querySelectorAll('amp-ambient-video')) v.connectedCallback();
      }
    },
  };

  const hook = () => {
    try { mk = MusicKit.getInstance(); } catch { mk = null; }
    if (!mk) return setTimeout(hook, 500);
    send('ready', true);
    sendDevices().then((outs) => { outputCount = outs.length; });
    send('track', track());
    send('playback', playback());
    mk.addEventListener('nowPlayingItemDidChange', () => {
      send('track', track());
      refreshIfOpen();
      paintFsBackground();
      if (quietOn) setTimeout(pauseLoops, 1500); // il nuovo brano può far partire altre animazioni continue
    });
    mk.addEventListener('queueItemsDidChange', refreshIfOpen);
    mk.addEventListener('queuePositionDidChange', refreshIfOpen);
    mk.addEventListener('playbackStateDidChange', () => {
      send('playback', playback());
      document.documentElement.classList.toggle('beats-playing', !!mk.isPlaying);
      playerLoops();
    });
    let last = 0;
    for (const ev of ['shuffleModeDidChange', 'repeatModeDidChange', 'playbackVolumeDidChange']) {
      mk.addEventListener(ev, () => send('playback', playback()));
    }
    mk.addEventListener('playbackVolumeDidChange', apGain);
    mk.addEventListener('playbackTimeDidChange', () => {
      const now = Date.now();
      if (now - last > 900) { last = now; send('playback', playback()); }
    });
  };

  // ---------- Coda e cronologia nel lettore grande ----------
  const Q = { open: false, tab: 'next', recent: [], recentAt: 0 };
  // Mentre testo e coda si scambiano si fermano barre e orologio del testo: ogni loro aggiornamento ricostruisce
  // i livelli della pagina e toglie fluidità. Per mezzo secondo non si nota
  const FLIP_MS = 480;
  let flipUntil = 0;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const info = (it) => {
    const a = it.attributes || {};
    const art = it.artwork || a.artwork;
    return {
      id: it.id,
      title: it.title || a.name || '',
      artist: it.artistName || a.artistName || '',
      art: art && art.url ? art.url.replace('{w}', 80).replace('{h}', 80).replace('{f}', 'jpg').replace('{c}', '') : '',
    };
  };
  const ICON = {
    queue: '<svg viewBox="0 0 24 24"><path d="M3 6h12M3 11h12M3 16h7"/><path d="M17 13v7.5"/><circle cx="15" cy="20" r="2"/><path d="M17 13l4-1.5"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M4 7h10M4 12h10M4 17h6"/><path d="M18 20V9M15 12l3-3 3 3"/></svg>',
    last: '<svg viewBox="0 0 24 24"><path d="M4 7h10M4 12h10M4 17h6"/><path d="M18 9v11M15 17l3 3 3-3"/></svg>',
    remove: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    lyrics: '<svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/></svg>',
    expand: '<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    airplay: '<svg viewBox="0 0 24 24"><path d="M5.5 16.5a9 9 0 1 1 13 0"/><path d="M8.6 13.6a5 5 0 1 1 6.8 0"/><path d="M12 14.5 7.5 20h9z" fill="currentColor"/></svg>',
    shrink: '<svg viewBox="0 0 24 24"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>',
  };
  let fsOn = false;
  let vizAccent = '#ff6a8a'; // colore d'accento per il visualizzatore, tenuto qui: rileggerlo dallo stile 30 volte al secondo costava
  let playGen = 0;
  const VIZ_W = 960, VIZ_H = 200; // tela del visualizzatore: piccola, la ingrandisce la scheda video

  async function loadRecent(force) {
    if (!force && Date.now() - Q.recentAt < 60000) return;
    try {
      const r = await mk.api.music('/v1/me/recent/played/tracks', { limit: 30 });
      Q.recent = r.data.data.map(info);
      Q.recentAt = Date.now();
    } catch {}
  }

  // Riproduce subito un brano che non è nella coda: lo mette dopo quello attuale e ci salta
  async function playNow(id) {
    if (!mk.queue.length) return mk.setQueue({ songs: [id], startPlaying: true });
    await mk.playNext({ songs: [id] });
    await mk.skipToNextItem();
  }

  // Sposta un brano tra i prossimi (indici della coda); quelli già ascoltati e l'attuale non si toccano
  function moveInQueue(from, to) {
    const pos = mk.queue.position;
    if (from <= pos || to <= pos || from === to) return;
    const moved = mk.queue.spliceQueueItems(from, 1, []);
    mk.queue.spliceQueueItems(to, 0, moved);
  }

  async function queueAction(act, idx, id) {
    try {
      const pos = mk.queue.position;
      if (act === 'jump') await mk.changeToMediaAtIndex(idx);
      else if (act === 'remove') mk.queue.remove(idx);
      else if (act === 'up') moveInQueue(idx, pos + 1); // subito dopo il brano attuale
      else if (act === 'move') moveInQueue(idx, id);
      else if (act === 'now') await playNow(id);
      else if (act === 'after') await mk.playNext({ songs: [id] });
      else if (act === 'later') await mk.playLater({ songs: [id] });
    } catch (e) { console.warn('coda', e); }
    renderQueue();
  }

  function row(it, actions, opts = {}) {
    const btns = actions.map(([act, icon, title]) => `<button data-act="${act}" title="${title}">${ICON[icon]}</button>`).join('');
    return `<li class="${opts.now ? 'now' : ''}${opts.sortable ? ' up' : ''}" data-idx="${opts.idx ?? ''}" data-id="${esc(it.id)}">
      ${opts.sortable ? '<span class="grip" title="Trascina per spostare"><i></i><i></i><i></i></span>' : ''}
      ${it.art ? `<img src="${esc(it.art)}" alt="" draggable="false">` : '<span class="ph"></span>'}
      <div class="tx"><b>${esc(it.title)}</b><span>${esc(it.artist)}</span></div>
      <div class="ac">${btns}</div></li>`;
  }

  let drag = null;            // brano che si sta trascinando nella coda
  let renderAfterDrag = false;
  async function renderQueue() {
    const panel = document.getElementById('beats-queue');
    if (!panel || !mk) return;
    if (drag && drag.active) { renderAfterDrag = true; return; } // non ridisegnare sotto il dito
    panel.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === Q.tab));
    const list = panel.querySelector('ol');
    const items = mk.queue.items || [];
    const pos = mk.queue.position;
    let html = '';
    if (Q.tab === 'next') {
      if (items[pos]) html += `<h4>In riproduzione</h4>` + row(info(items[pos]), [], { now: true, idx: pos });
      const upcoming = items.map((it, i) => [it, i]).filter(([, i]) => i > pos);
      html += `<h4>Prossimi · ${upcoming.length}</h4>`;
      html += upcoming.map(([it, i]) => row(info(it), [['jump', 'play', 'Riproduci ora'], ['up', 'next', 'Sposta subito dopo'], ['remove', 'remove', 'Togli dalla coda']], { idx: i, sortable: true })).join('')
        || '<p class="empty">Nessun brano in coda dopo questo.</p>';
    } else {
      const played = items.map((it, i) => [it, i]).filter(([, i]) => i < pos).reverse();
      if (played.length) {
        html += `<h4>In questa sessione</h4>`;
        html += played.map(([it, i]) => row(info(it), [['jump', 'play', 'Riascolta ora'], ['after', 'next', 'Riproduci subito dopo'], ['later', 'last', 'Riproduci per ultimo']], { idx: i })).join('');
      }
      await loadRecent();
      html += `<h4>Ascoltati di recente</h4>`;
      html += Q.recent.map((it) => row(it, [['now', 'play', 'Riproduci ora'], ['after', 'next', 'Riproduci subito dopo'], ['later', 'last', 'Riproduci per ultimo']])).join('')
        || '<p class="empty">Nessun ascolto recente.</p>';
    }
    if (html !== list.drawn) { list.drawn = html; list.innerHTML = html; } // ridisegnare centinaia di righe blocca il giro della carta
  }
  // Nel lettore grande la coda è sempre pronta, anche chiusa: all'apertura non resta nulla da disegnare
  let queueIdle = 0;
  const prepareQueue = () => {
    if (queueIdle) return;
    queueIdle = requestIdleCallback(() => { queueIdle = 0; renderQueue(); }, { timeout: 1500 });
  };

  function deepFind(root, sel) {
    const inside = root.shadowRoot || root;
    const hit = inside.querySelector(sel);
    if (hit) return hit;
    for (const e of inside.querySelectorAll('*')) {
      if (e.shadowRoot) { const r = deepFind(e, sel); if (r) return r; }
    }
    return null;
  }

  function placeQueueButton() {
    const btn = document.getElementById('beats-queue-btn');
    const controls = document.querySelector('[data-testid="lyrics-fullscreen-modal"] apple-music-playback-controls');
    if (!btn || !controls) return;
    const fs = document.getElementById('beats-fs-btn');
    const ly = document.getElementById('beats-lyrics-btn');
    const air = document.getElementById('beats-airplay-btn');
    // AirPlay sta subito a sinistra del pulsante shuffle, che è in una shadow root annidata
    const placeAirplay = (size, mid) => {
      if (!air) return;
      const box = controls.getBoundingClientRect();
      const shuffle = deepFind(controls, 'amp-playback-controls-shuffle');
      const left = shuffle && shuffle.getBoundingClientRect().width ? shuffle.getBoundingClientRect().left : box.left + box.width / 2 - 140;
      air.style.left = `${Math.round(left - size - 10)}px`;
      air.style.top = `${Math.round(mid - size / 2)}px`;
    };
    // A schermo intero i pulsanti di Beats stanno in fondo alla barra dei comandi
    const bar = fsOn && document.querySelector('[data-testid="lyrics-fullscreen-modal"] .lyrics__controls');
    if (bar) {
      const b = bar.getBoundingClientRect();
      const top = `${Math.round(b.top + b.height / 2 - 16)}px`;
      [[ly, 140], [btn, 98], [fs, 56]].forEach(([el, off]) => { if (el) { el.style.left = `${Math.round(b.right - off)}px`; el.style.top = top; } });
      placeAirplay(32, b.top + b.height / 2);
      return;
    }
    const r = controls.getBoundingClientRect();
    // Allinea al centro dei pulsanti veri (play, avanti...), anche se stanno in una shadow root
    const root = controls.shadowRoot || controls;
    const rects = [...root.querySelectorAll('button')].map((b) => b.getBoundingClientRect()).filter((b) => b.width > 0);
    const right = r.right; // alcuni pulsanti stanno in shadow root annidate: il bordo destro lo dà il contenitore
    const mid = rects.length ? rects.reduce((s, b) => s + b.top + b.height / 2, 0) / rects.length : r.top + r.height / 2;
    btn.style.left = `${Math.round(right + 14)}px`;
    btn.style.top = `${Math.round(mid - 19)}px`;
    placeAirplay(38, mid);
    if (fs) { fs.style.left = `${Math.round(right + 60)}px`; fs.style.top = btn.style.top; }
    if (ly) { ly.style.left = `${Math.round(right + 106)}px`; ly.style.top = btn.style.top; }
  }

  let lyricsOn = true;
  function paintLyricsButton(on) {
    lyricsOn = on;
    playerLoops();
    const b = document.getElementById('beats-lyrics-btn');
    if (!b) return;
    b.innerHTML = ICON.lyrics;
    b.classList.toggle('on', on);
    b.title = on ? 'Nascondi il testo' : 'Mostra il testo';
  }

  // Sfondo leggero: la copertina attuale, sfocata dal CSS una volta sola
  function paintFsBackground() {
    const it = mk && mk.nowPlayingItem;
    if (!it) return;
    const art = info(it).art.replace('80x80', '400x400');
    if (art) for (const bg of document.querySelectorAll('#beats-fs-bg, .beats-cover-bg')) bg.style.backgroundImage = `url("${art}")`;
  }

  function paintFsButton() {
    const fs = document.getElementById('beats-fs-btn');
    if (!fs) return;
    fs.innerHTML = fsOn ? ICON.shrink : ICON.expand;
    fs.title = fsOn ? 'Esci dallo schermo intero (Esc)' : 'Schermo intero senza bordi';
    fs.classList.toggle('on', fsOn);
  }

  function setupQueueUi(modal) {
    if (document.getElementById('beats-queue-btn')) return;
    const btn = document.createElement('button');
    btn.id = 'beats-queue-btn';
    btn.title = 'Coda e cronologia';
    btn.innerHTML = ICON.queue;
    const panel = document.createElement('aside');
    panel.id = 'beats-queue';
    panel.innerHTML = `<header><div class="tabs"><button data-tab="next">Coda</button><button data-tab="history">Cronologia</button></div>
      <button class="x" title="Chiudi">${ICON.remove}</button></header><ol></ol>`;
    const fsBtn = document.createElement('button');
    fsBtn.id = 'beats-fs-btn';
    fsBtn.onclick = (e) => { e.stopPropagation(); send('fsToggle', true); };
    const lyBtn = document.createElement('button');
    lyBtn.id = 'beats-lyrics-btn';
    // Con la coda aperta il pulsante del testo rigira la carta sul testo; altrimenti mostra/nasconde il testo
    lyBtn.onclick = (e) => {
      e.stopPropagation();
      if (Q.open) { toggle(false); if (!lyricsOn) send('lyricsToggle', true); }
      else send('lyricsToggle', true);
    };
    const airBtn = document.createElement('button');
    airBtn.id = 'beats-airplay-btn';
    airBtn.title = 'AirPlay: ascolta su HomePod e Apple TV';
    airBtn.innerHTML = ICON.airplay;
    airBtn.classList.toggle('on', ap.wanted);
    airBtn.onclick = (e) => { e.stopPropagation(); send('airplayMenu', true); };
    const bg = document.createElement('div');
    bg.id = 'beats-fs-bg';
    // Visualizzatore "finto" (l'audio protetto non si può analizzare): barre e bagliore animati solo con CSS
    const viz = document.createElement('div');
    viz.id = 'beats-viz';
    viz.innerHTML = `<canvas width="${VIZ_W}" height="${VIZ_H}"></canvas>`;
    const glow = document.createElement('div');
    glow.id = 'beats-glow';
    modal.prepend(bg, glow, viz);
    modal.append(airBtn, lyBtn, btn, fsBtn, panel);
    paintFsButton();
    paintLyricsButton(lyricsOn);
    paintFsBackground();

    panel.inert = true; // chiusa resta pronta sullo schermo, ma non si raggiunge né col mouse né da tastiera
    const toggle = (open) => {
      Q.open = open;
      flipUntil = performance.now() + FLIP_MS;
      panel.inert = !open;
      panel.classList.toggle('open', open);
      btn.classList.toggle('on', open);
      document.documentElement.classList.toggle('beats-queue-open', open);
      if (open) {
        renderQueue();
        loadRecent(true).then(() => { if (Q.tab === 'history') renderQueue(); });
      }
      // Solo senza testo la colonna dei comandi si sposta: altrimenti non serve rimisurare proprio durante il passaggio
      if (document.documentElement.classList.contains('beats-nolyrics')) requestAnimationFrame(() => requestAnimationFrame(placeQueueButton));
      playerLoops();
    };
    btn.onclick = (e) => { e.stopPropagation(); toggle(!Q.open); };
    panel.querySelector('.x').onclick = () => toggle(false);
    panel.querySelector('.tabs').onclick = (e) => {
      const t = e.target.closest('[data-tab]');
      if (t) { Q.tab = t.dataset.tab; renderQueue(); }
    };
    // Trascinamento dei prossimi brani: la riga segue il puntatore, le altre si scostano per farle posto
    const list = panel.querySelector('ol');
    let suppressClick = false;
    list.addEventListener('pointerdown', (e) => {
      const li = e.target.closest('li.up');
      if (!li || e.button !== 0 || e.target.closest('button')) return;
      const rows = [...list.querySelectorAll('li.up')];
      const rects = rows.map((r) => r.getBoundingClientRect());
      drag = {
        li, rows, from: rows.indexOf(li), to: rows.indexOf(li), startY: e.clientY, startScroll: list.scrollTop,
        rowH: rects.length > 1 ? rects[1].top - rects[0].top : rects[0].height, active: false, id: e.pointerId,
      };
    });
    list.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dy = e.clientY - drag.startY + (list.scrollTop - drag.startScroll);
      if (!drag.active) {
        if (Math.abs(dy) < 6) return;
        drag.active = true;
        drag.li.setPointerCapture(e.pointerId);
        drag.li.classList.add('dragging');
        list.classList.add('sorting');
      }
      drag.li.style.transform = `translate3d(0, ${dy}px, 0) scale(1.02)`;
      const to = Math.max(0, Math.min(drag.rows.length - 1, drag.from + Math.round(dy / drag.rowH)));
      if (to !== drag.to) {
        drag.to = to;
        drag.rows.forEach((r, k) => {
          if (r === drag.li) return;
          let shift = 0;
          if (drag.from < to && k > drag.from && k <= to) shift = -drag.rowH;
          if (drag.from > to && k >= to && k < drag.from) shift = drag.rowH;
          r.style.transform = shift ? `translate3d(0, ${shift}px, 0)` : '';
        });
      }
      // Vicino ai bordi la lista scorre da sola
      const box = list.getBoundingClientRect();
      if (e.clientY < box.top + 50) list.scrollTop -= 12;
      else if (e.clientY > box.bottom - 50) list.scrollTop += 12;
    });
    const endDrag = () => {
      if (!drag) return;
      const d = drag;
      drag = null;
      if (!d.active) return;
      suppressClick = true;
      setTimeout(() => { suppressClick = false; }, 50);
      list.classList.remove('sorting');
      d.li.classList.remove('dragging');
      d.rows.forEach((r) => { r.style.transform = ''; });
      if (d.to !== d.from) queueAction('move', +d.li.dataset.idx, +d.rows[d.to].dataset.idx);
      else if (renderAfterDrag) renderQueue();
      renderAfterDrag = false;
    };
    list.addEventListener('pointerup', endDrag);
    list.addEventListener('pointercancel', endDrag);

    list.onclick = (e) => {
      if (suppressClick) return;
      const b = e.target.closest('button[data-act]');
      const li = e.target.closest('li');
      if (!li) return;
      const idx = li.dataset.idx === '' ? -1 : +li.dataset.idx;
      if (b) return queueAction(b.dataset.act, idx, li.dataset.id);
      // clic sulla riga: riproduci
      if (li.classList.contains('now')) return;
      queueAction(idx >= 0 ? 'jump' : 'now', idx, li.dataset.id);
    };
    const controls = modal.querySelector('apple-music-playback-controls');
    if (controls) new ResizeObserver(placeQueueButton).observe(controls);
    placeQueueButton();
    setTimeout(placeQueueButton, 400);
    if (Q.open) toggle(true);
    else prepareQueue();
  }
  window.addEventListener('resize', placeQueueButton);

  // Rotellina del mouse sul volume. L'ascolto si aggancia solo al controllo del volume, al primo passaggio del
  // puntatore: uno sulla finestra intera farebbe passare ogni scorrimento della pagina dal thread principale
  const VOLUME_STEP = 0.02;
  const wheelReady = new WeakSet();
  const onVolumeWheel = (e) => {
    e.preventDefault();
    if (!mk || !e.deltaY) return;
    mk.volume = Math.round(Math.min(1, Math.max(0, mk.volume + (e.deltaY < 0 ? VOLUME_STEP : -VOLUME_STEP))) * 100) / 100;
  };
  document.addEventListener('pointerover', (e) => {
    const el = e.target.closest && e.target.closest('.chrome-volume, amp-chrome-volume');
    if (!el || wheelReady.has(el)) return;
    wheelReady.add(el);
    el.addEventListener('wheel', onVolumeWheel, { passive: false });
  }, { passive: true });

  // A schermo intero Esc riporta in finestra: lo si intercetta prima di Apple, che chiude il lettore
  // al rilascio del tasto (keyup sul body). Va quindi fermato anche il keyup che segue.
  let swallowEscUp = false;
  window.addEventListener('keydown', (e) => {
    if (fsOn && e.key === 'Escape') {
      e.preventDefault();
      e.stopImmediatePropagation();
      swallowEscUp = true;
      send('fsExit', true);
    }
  }, true);
  window.addEventListener('keyup', (e) => {
    if (e.key === 'Escape' && (swallowEscUp || fsOn)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      swallowEscUp = false;
    }
  }, true);
  // A schermo intero la barra spaziatrice è play/pausa, anche con un pulsante selezionato: fermando pure il rilascio
  // del tasto, quel pulsante non scatta. Tenendola premuta non si alterna a ripetizione
  const typing = (t) => t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
  for (const type of ['keydown', 'keyup']) {
    window.addEventListener(type, (e) => {
      if (!fsOn || e.code !== 'Space' || typing(e.composedPath()[0])) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (type === 'keydown' && !e.repeat && mk) playPause();
    }, true);
  }
  const refreshIfOpen = () => {
    if (Q.open) renderQueue();
    else if (document.getElementById('beats-queue')) prepareQueue();
  };

  // Cambio pagina: all'arrivo di ogni copertina Apple legge uno stile calcolato, che obbliga a ricalcolare gli stili
  // della pagina (decine di volte per pagina). Consegnando insieme, una volta per fotogramma, gli avvisi di caricamento
  // le letture dopo la prima non costano nulla: il ricalcolo scende da 600-700 a 120-150 ms
  const heldLoads = new Set(), ownLoads = new WeakSet();
  let loadFrame = 0;
  const flushLoads = () => {
    loadFrame = 0;
    const imgs = [...heldLoads];
    heldLoads.clear();
    for (const img of imgs) {
      const e = new Event('load');
      ownLoads.add(e);
      img.dispatchEvent(e);
    }
  };
  document.addEventListener('load', (e) => {
    const img = e.target;
    // Senza fotogrammi (finestra nascosta) l'avviso resterebbe fermo: passa subito
    if (ownLoads.has(e) || document.hidden || !(img instanceof HTMLImageElement) || !img.closest('main')) return;
    e.stopImmediatePropagation();
    heldLoads.add(img);
    if (!loadFrame) loadFrame = requestAnimationFrame(flushLoads);
  }, true);

  // Risposta immediata al clic sulla barra laterale: Apple cambia voce solo quando la pagina nuova è pronta
  const LIBRARY_LINK = /\/library\/(songs|albums|artists)\/?$/;
  let navTimer = 0, navLink = null, navCloseView = false;
  const navDone = () => {
    clearTimeout(navTimer);
    window.__beatsFastNav = false;
    document.documentElement.classList.remove('beats-navigating');
    if (navLink) navLink.classList.remove('beats-nav-pending');
    navLink = null;
  };
  document.addEventListener('click', (e) => {
    const a = e.target.closest && e.target.closest('nav a[href]');
    if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey) return;
    // Il logo non porta da nessuna parte, nemmeno da tastiera (i clic da programma di go() invece passano)
    if (e.isTrusted && a.closest('.logo')) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    const pathname = new URL(a.href, location.href).pathname;
    const library = libraryViews && pathname.match(LIBRARY_LINK);
    if (library) {
      e.preventDefault();
      e.stopImmediatePropagation();
      send('libraryNav', library[1]);
      return;
    }
    const inSideView = document.documentElement.classList.contains('beats-side-view');
    if (pathname === location.pathname) { if (inSideView) send('libraryNav', null); return; }
    navCloseView = inSideView; // la vista di Beats resta finché la pagina scelta non è pronta
    navDone();
    window.__beatsFastNav = /\/(home|library\/all-playlists|library\/recently-added|radio|new)\/?$/.test(pathname);
    navLink = a;
    navBefore = mainText();
    a.classList.add('beats-nav-pending');
    document.documentElement.classList.add('beats-navigating');
    navTimer = setTimeout(navDone, 8000); // Apple può anche non cambiare pagina (rete assente)
  }, true);
  document.addEventListener('pointerover', (e) => {
    if (e.target.closest && e.target.closest('nav a[href$="/home"]')) window.__beatsRefreshHome?.();
  }, true);
  // Difetto di Apple: se si clicca mentre la pagina di prima finisce di caricare, l'indirizzo cambia ma resta il vecchio
  // contenuto. Se dopo un attimo è ancora tutto uguale, si richiede la pagina al suo router, una volta sola
  const mainText = () => (document.querySelector('main')?.innerText || '').slice(0, 120);
  let navBefore = null;
  if (window.navigation) window.navigation.addEventListener('currententrychange', () => {
    const before = navBefore;
    navBefore = null;
    navDone();
    if (navCloseView) { navCloseView = false; send('libraryNav', null); }
    if (before === null) return;
    const path = location.pathname;
    setTimeout(() => {
      if (location.pathname !== path || mainText() !== before) return;
      const state = { id: `beats-${Date.now()}` };
      history.replaceState(state, '', location.pathname + location.search);
      dispatchEvent(new PopStateEvent('popstate', { state }));
    }, 800);
  });

  // Lettore a schermo intero di Apple (clic sulla copertina nel player): avvisa l'app per il vero schermo intero
  let fullOpen = false;
  // Ad ogni modifica della pagina (migliaia durante un cambio pagina) basta leggere la lunghezza di una
  // collezione "viva": costo quasi zero, invece di ricercare in tutto il documento
  const fullModals = document.getElementsByClassName('lyrics__container');
  function checkPlayer() {
    let modal = null;
    for (let i = 0; i < fullModals.length; i++) {
      if (fullModals[i].dataset.testid === 'lyrics-fullscreen-modal') { modal = fullModals[i]; break; }
    }
    if (modal) setupQueueUi(modal);
    const mini = modal ? null : miniPlayer();
    document.documentElement.classList.toggle('beats-mini-open', !!mini);
    const open = !!modal || !!mini;
    if (open !== fullOpen) { fullOpen = open; send('fullplayer', open); playerLoops(); pageCovered(open); }
  }
  new MutationObserver(checkPlayer).observe(document.body, { childList: true, subtree: true });

  // Lettore compatto di Apple, quello delle finestre strette (per esempio a metà schermo): un riquadro che sale dal
  // basso senza uno sfondo suo, quindi trasparente sopra la pagina, e sotto la barra laterale. Gli si dà la copertina
  // sfocata del lettore grande e lo si porta sopra a tutto. Il pannello laterale dei testi, più stretto, resta com'è
  const miniWatched = new WeakSet();
  function miniPlayer() {
    const dialog = document.getElementById('now-playing-dialog');
    const sheet = dialog && dialog.querySelector('.sliding-modal');
    if (!sheet) return null;
    if (!miniWatched.has(sheet)) {
      miniWatched.add(sheet);
      new MutationObserver(checkPlayer).observe(sheet, { attributes: true, attributeFilter: ['class'] }); // si chiude togliendo una classe
    }
    if (!sheet.classList.contains('is-open')) return null;
    // La misura solo all'apertura: mentre è aperto il testo cambia la pagina di continuo
    if (!document.documentElement.classList.contains('beats-mini-open') && sheet.getBoundingClientRect().width < innerWidth * 0.9) return null;
    const back = sheet.querySelector('.sliding-modal-backdrop');
    if (back && !back.querySelector('.beats-cover-bg')) {
      const bg = document.createElement('div');
      bg.className = 'beats-cover-bg';
      back.prepend(bg);
      paintFsBackground();
    }
    return sheet;
  }

  // Lettore grande aperto: la pagina sotto (Home, album...) è coperta del tutto e, finita l'animazione d'apertura, non
  // si calcola più. A ogni fotogramma del testo animato costava quasi quanto il lettore. Alla chiusura torna subito
  let coverTimer = 0;
  function pageCovered(on) {
    clearTimeout(coverTimer);
    if (on) coverTimer = setTimeout(() => { if (fullOpen) document.documentElement.classList.add('beats-page-covered'); }, 900);
    else document.documentElement.classList.remove('beats-page-covered');
  }
  // La chiusura ha la sua animazione, durante la quale la pagina sotto si rivede: la si ridisegna già al clic
  const uncover = () => {
    pageCovered(false);
    setTimeout(() => { if (fullOpen) pageCovered(true); }, 1500); // non si è chiuso (es. Esc esce solo dallo schermo intero)
  };
  document.addEventListener('click', (e) => {
    if (fullOpen && e.target.closest && e.target.closest('[data-testid="lyrics-fullscreen-modal"] .close-button, #now-playing-dialog [data-testid="sliding-modal-collapse"]')) uncover();
  }, true);
  document.addEventListener('keydown', (e) => { if (fullOpen && e.key === 'Escape') uncover(); }, true);

  // Orologio del testo: Apple passa al testo il tempo arrotondato al secondo, così ogni riga si accende fino a
  // mezzo secondo fuori tempo. Mentre il testo è a schermo e la musica suona gli si dà il tempo vero, 5 volte al
  // secondo (ogni aggiornamento ridisegna il testo; le righe partono già 0,15 s prima, quindi basta), e si ignora
  // quello arrotondato (riscriverlo farebbe tremare le righe)
  const CLOCK_PROP = 'currentPlaybackMillis';
  let clockTimer = null, clockEl = null, clockSet = null, clockWait = 0;
  function clockRelease() {
    if (clockEl) delete clockEl[CLOCK_PROP];
    clockEl = null;
  }
  function clockAttach() {
    const host = document.querySelector('[data-testid="lyrics-fullscreen-modal"] amp-lyrics, #now-playing-dialog amp-lyrics');
    const el = host && deepFind(host, 'amp-lyrics-display-time-synced');
    if (!el) return;
    let desc = null;
    for (let o = Object.getPrototypeOf(el); o && !desc; o = Object.getPrototypeOf(o)) desc = Object.getOwnPropertyDescriptor(o, CLOCK_PROP);
    if (!desc || !desc.set) return;
    Object.defineProperty(el, CLOCK_PROP, { configurable: true, get() { return desc.get.call(el); }, set() {} });
    clockEl = el;
    clockSet = desc.set;
  }
  function clockTick(audio) {
    if (performance.now() < flipUntil) return;
    if (!clockEl || !clockEl.isConnected) {
      clockRelease();
      if (++clockWait % 3) return; // il testo del brano non è ancora pronto: si ricontrolla ogni tanto
      clockAttach();
      if (!clockEl) return;
    }
    clockSet.call(clockEl, audio.currentTime * 1000);
  }
  function playerLoops() {
    const audio = document.getElementById('apple-music-player');
    // Non in primo piano il testo resta all'orologio di Apple: si aggiorna ogni secondo invece di 5 volte
    const run = !!audio && fullOpen && lyricsOn && !Q.open && !quietOn && !document.hidden && !!mk && mk.isPlaying;
    if (run && !clockTimer) { clockWait = 2; clockTimer = setInterval(() => clockTick(audio), 200); }
    else if (!run && clockTimer) { clearInterval(clockTimer); clockTimer = null; clockRelease(); }
    // Testo animato a fotogrammi alterni sugli schermi oltre i 100 Hz (vedi preload-apple.js)
    window.__beatsHalfRate = fullOpen && !document.hidden;
    vizCheck();
  }
  document.addEventListener('visibilitychange', playerLoops);

  // Visualizzatore "finto" (l'audio protetto non si può analizzare): barre disegnate su una sola tela, 30 volte al
  // secondo. Con un elemento animato per barra, più una maschera sopra, costava più di tutto il resto del lettore.
  // A musica ferma le barre scendono piano e poi il disegno si ferma
  const VIZ_BARS = 48, VIZ_LOW = 0.08;
  const vizBars = Array.from({ length: VIZ_BARS }, (_, i) => ({
    d: 0.55 + ((i * 37) % 23) / 25, delay: ((i * 53) % 17) / 10, h: 0.35 + ((i * 29) % 13) / 20, v: VIZ_LOW,
  }));
  let vizTimer = null, vizFill = null, vizFillKey = '';
  function vizFrame() {
    const canvas = document.querySelector('#beats-viz canvas');
    const shown = fullOpen && !quietOn && !document.hidden && document.documentElement.dataset.viz === 'bars';
    if (!canvas || !shown) { clearInterval(vizTimer); vizTimer = null; return; }
    if (performance.now() < flipUntil) return;
    const ctx = canvas.getContext('2d');
    const cyber = document.documentElement.classList.contains('beats-skin-cyber');
    const accent = vizAccent;
    const gengy = document.documentElement.classList.contains('beats-skin-gengy');
    const key = accent + cyber + gengy;
    if (key !== vizFillKey) {
      vizFillKey = key;
      vizFill = ctx.createLinearGradient(0, VIZ_H, 0, 0);
      if (cyber) { vizFill.addColorStop(0, '#fcee0a'); vizFill.addColorStop(0.5, '#ff003c'); }
      else if (gengy) { vizFill.addColorStop(0, '#7b3fe0'); vizFill.addColorStop(0.55, '#e8364f'); }
      else { vizFill.addColorStop(0, accent); vizFill.addColorStop(0.45, `color-mix(in srgb, ${accent} 35%, transparent)`); }
      vizFill.addColorStop(1, 'rgba(0, 0, 0, 0)');
    }
    const playing = !!mk && mk.isPlaying;
    const t = performance.now() / 1000, w = VIZ_W / VIZ_BARS, gap = w * 0.25;
    let moving = playing;
    ctx.clearRect(0, 0, VIZ_W, VIZ_H);
    ctx.fillStyle = vizFill;
    for (let i = 0; i < VIZ_BARS; i++) {
      const b = vizBars[i];
      let target = VIZ_LOW;
      if (playing) {
        const p = ((t + b.delay) / b.d) % 2, u = p < 1 ? p : 2 - p;
        target = u < 0.6 ? VIZ_LOW + (b.h - VIZ_LOW) * (u / 0.6) : b.h - b.h * 0.5 * ((u - 0.6) / 0.4);
      }
      b.v += (target - b.v) * 0.35;
      if (Math.abs(b.v - target) > 0.002) moving = true;
      const h = b.v * VIZ_H;
      if (gengy) { // denti appuntiti al posto delle barre
        const x = i * w;
        ctx.beginPath();
        ctx.moveTo(x, VIZ_H);
        ctx.lineTo(x + w / 2, VIZ_H - h);
        ctx.lineTo(x + w, VIZ_H);
        ctx.fill();
      } else ctx.fillRect(i * w + gap / 2, VIZ_H - h, w - gap, h);
    }
    if (!moving) { clearInterval(vizTimer); vizTimer = null; }
  }
  function vizCheck() {
    const wanted = fullOpen && !quietOn && !document.hidden && document.documentElement.dataset.viz === 'bars';
    if (wanted && !vizTimer) { vizTimer = setInterval(vizFrame, 1000 / 30); vizFrame(); }
  }

  const wait = () => (window.MusicKit && MusicKit.getInstance ? hook() : setTimeout(wait, 400));
  wait();
})();
