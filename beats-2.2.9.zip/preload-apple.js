// Preload della pagina music.apple.com: un solo canale, in uscita, per inviare all'app lo stato del player.
const { contextBridge, ipcRenderer, webFrame } = require('electron');

// Tutte le playlist, Aggiunti di recente, Radio e Novità: Apple aspetta fino a più di un secondo di risposte prima di
// cambiare pagina. Solo durante quel clic (__beatsFastNav, messo da page.js) si risponde subito con le ultime ricevute,
// se hanno meno di un giorno, e intanto si aggiornano per la volta dopo. Le risposte restano sul PC, separate per
// account. Va inserito qui perché Apple si tiene un riferimento a fetch all'avvio.
webFrame.executeJavaScript(`(() => {
  const real = window.fetch;
  const PREFIX = 'beats-fast:';
  const FAST = /\\/v1\\/(me\\/library(\\/playlist-folders\\/[^/]+\\/children|\\/playlists\\/[^/]+\\/tracks|\\/recently-added)?|editorial\\/[^/]+\\/groupings)\\?/;
  const MAX_AGE = 24 * 60 * 60 * 1000;
  const hash = (s) => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return h; };
  const save = (key, res) => res.clone().text().then((text) => {
    try { if (text.length < 1500000) localStorage.setItem(key, Date.now() + '|' + text); } catch {}
  }).catch(() => {});
  const forget = () => {
    try { Object.keys(localStorage).filter((k) => k.startsWith(PREFIX)).forEach((k) => localStorage.removeItem(k)); } catch {}
  };
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || String(input);
    const method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
    if (method !== 'GET') {
      if (url.includes('/v1/me/library')) forget(); // playlist o libreria modificate
      return real.apply(this, arguments);
    }
    if (!window.__beatsFastNav || !FAST.test(url)) return real.apply(this, arguments);
    const headers = new Headers((init && init.headers) || (input && input.headers) || {});
    const token = headers.get('media-user-token') || headers.get('authorization');
    if (!token) return real.apply(this, arguments);
    const key = PREFIX + hash(token) + ':' + url;
    let known = null;
    try {
      const saved = localStorage.getItem(key);
      const bar = saved ? saved.indexOf('|') : -1;
      if (bar > 0 && Date.now() - Number(saved.slice(0, bar)) < MAX_AGE) known = saved.slice(bar + 1);
    } catch {}
    const fresh = real.call(this, typeof input === 'string' ? input : input.clone(), init);
    const keep = fresh.then((res) => { if (res.status === 200) save(key, res); return res; });
    if (known === null) return keep;
    keep.catch(() => {});
    return Promise.resolve(new Response(known, { status: 200, headers: { 'content-type': 'application/json' } }));
  };
})()`);

const ALLOWED = new Set(['track', 'playback', 'ready', 'fullplayer', 'devices', 'fsToggle', 'fsExit', 'lyricsToggle', 'apcm', 'airplayMenu', 'libraryNav']);

contextBridge.exposeInMainWorld('ariaBridge', {
  send(type, payload) {
    if (ALLOWED.has(type)) ipcRenderer.send('aria:from-page', type, payload);
  },
});
