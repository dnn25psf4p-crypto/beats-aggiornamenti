// Preload della pagina music.apple.com: un solo canale, in uscita, per inviare all'app lo stato del player.
const { contextBridge, ipcRenderer, webFrame } = require('electron');

// Limite ai ridisegni della pagina: il lettore di Apple chiede un fotogramma a ogni aggiornamento dello schermo (144 al
// secondo su un monitor veloce), anche con la sua animazione nascosta. Quando Beats non è in primo piano page.js imposta
// __beatsMaxFps e i ridisegni scendono; con 0 non c'è limite. Le animazioni CSS e lo scorrimento non passano da qui.
webFrame.executeJavaScript(`(() => {
  const nativeRaf = window.requestAnimationFrame.bind(window);
  let queue = new Map(), nextId = 1, scheduled = false, last = 0;
  window.__beatsMaxFps = 0;
  const run = (now) => {
    scheduled = false;
    last = now;
    const batch = queue;
    queue = new Map();
    for (const cb of batch.values()) {
      try { cb(now); } catch (e) { setTimeout(() => { throw e; }); }
    }
  };
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    const fps = window.__beatsMaxFps;
    const wait = fps ? last + 1000 / fps - performance.now() - 4 : 0;
    if (wait > 1) setTimeout(() => nativeRaf(run), wait);
    else nativeRaf(run);
  };
  window.requestAnimationFrame = (cb) => {
    const id = nextId++;
    queue.set(id, cb);
    schedule();
    return id;
  };
  window.cancelAnimationFrame = (id) => { queue.delete(id); };
})()`);

// Home, Tutte le playlist, Aggiunti di recente, Radio e Novità: Apple aspetta fino a più di un secondo di risposte prima
// di cambiare pagina. Solo durante quel clic (__beatsFastNav, messo da page.js) si risponde subito con le ultime ricevute,
// se hanno meno di un giorno, e intanto si aggiornano per la volta dopo. Le risposte restano sul PC, separate per
// account. Va inserito qui perché Apple si tiene un riferimento a fetch all'avvio.
webFrame.executeJavaScript(`(() => {
  const real = window.fetch;
  const PREFIX = 'beats-fast:';
  const FAST = /\\/v1\\/(me\\/(recommendations|library(\\/playlist-folders\\/[^/]+\\/children|\\/playlists\\/[^/]+\\/tracks|\\/recently-added)?)|editorial\\/[^/]+\\/groupings)\\?/;
  const MAX_AGE = 24 * 60 * 60 * 1000;
  const hash = (s) => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return h; };
  const save = (key, res) => res.clone().text().then((text) => {
    try { if (text.length < 1500000) localStorage.setItem(key, Date.now() + '|' + text); } catch {}
  }).catch(() => {});
  const forget = () => {
    try { Object.keys(localStorage).filter((k) => k.startsWith(PREFIX)).forEach((k) => localStorage.removeItem(k)); } catch {}
  };
  let refreshHome = null, refreshedAt = 0;
  window.__beatsRefreshHome = () => {
    if (!refreshHome || Date.now() - refreshedAt < 20000) return;
    refreshedAt = Date.now();
    refreshHome().catch(() => {});
  };
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || String(input);
    const method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
    if (method !== 'GET') {
      if (url.includes('/v1/me/library')) forget(); // playlist o libreria modificate
      return real.apply(this, arguments);
    }
    const isHome = url.includes('/v1/me/recommendations?');
    if (!FAST.test(url) || !(window.__beatsFastNav || isHome)) return real.apply(this, arguments);
    const headers = new Headers((init && init.headers) || (input && input.headers) || {});
    const token = headers.get('media-user-token') || headers.get('authorization');
    if (!token) return real.apply(this, arguments);
    const key = PREFIX + hash(token) + ':' + url;
    const request = () => real.call(window, typeof input === 'string' ? input : input.clone(), init);
    const keepFresh = () => request().then((res) => { if (res.status === 200) save(key, res); return res; });
    // La Home appena aperta si aggiorna anche passandoci sopra col mouse, così al clic è già quella di adesso
    if (isHome) refreshHome = keepFresh;
    let known = null;
    if (window.__beatsFastNav) try {
      const saved = localStorage.getItem(key);
      const bar = saved ? saved.indexOf('|') : -1;
      if (bar > 0 && Date.now() - Number(saved.slice(0, bar)) < MAX_AGE) known = saved.slice(bar + 1);
    } catch {}
    const keep = keepFresh();
    if (known === null) return keep;
    keep.catch(() => {});
    // Prima lascia disegnare la voce appena cliccata: la pagina nuova blocca lo schermo per un attimo mentre si costruisce
    return new Promise((done) => {
      const timer = setTimeout(done, 100); // senza fotogrammi (finestra nascosta) non aspetta
      requestAnimationFrame(() => { clearTimeout(timer); setTimeout(done); });
    }).then(() => new Response(known, { status: 200, headers: { 'content-type': 'application/json' } }));
  };
})()`);

// Copertine video spente: ogni riquadro animato della Home (sono 15) avvia comunque un lettore video, che misura la pagina
// e poi fallisce perché il video è bloccato: oltre 150 ms di lavoro a ogni passaggio sulla Home. Così il riquadro non parte
// e resta la copertina fissa. Va inserito qui perché Apple registra i suoi componenti all'avvio; page.js tiene aggiornato il valore.
webFrame.executeJavaScript(`(() => {
  try { window.__beatsCovers = localStorage.getItem('beats-covers') === '1'; } catch { window.__beatsCovers = false; }
  const define = customElements.define;
  customElements.define = function (name, cls, options) {
    if (name === 'amp-ambient-video') {
      const connected = cls.prototype.connectedCallback;
      cls.prototype.connectedCallback = function () { if (window.__beatsCovers && connected) return connected.apply(this, arguments); };
    }
    return define.call(this, name, cls, options);
  };
})()`);

const ALLOWED = new Set(['track', 'playback', 'ready', 'fullplayer', 'devices', 'fsToggle', 'fsExit', 'lyricsToggle', 'apcm', 'airplayMenu', 'libraryNav']);

contextBridge.exposeInMainWorld('ariaBridge', {
  send(type, payload) {
    if (ALLOWED.has(type)) ipcRenderer.send('aria:from-page', type, payload);
  },
});
