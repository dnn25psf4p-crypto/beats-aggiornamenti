// Preload della pagina music.apple.com: un solo canale, in uscita, per inviare all'app lo stato del player.
const { contextBridge, ipcRenderer } = require('electron');

const ALLOWED = new Set(['track', 'playback', 'ready', 'fullplayer', 'devices', 'fsToggle', 'fsExit', 'lyricsToggle']);

contextBridge.exposeInMainWorld('ariaBridge', {
  send(type, payload) {
    if (ALLOWED.has(type)) ipcRenderer.send('aria:from-page', type, payload);
  },
});
