// Preload delle finestre locali di Beats (barra del titolo, impostazioni, viste, ricerca rapida).
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('aria', {
  cmd: (name, arg) => ipcRenderer.send('aria:cmd', name, arg),
  onState: (cb) => ipcRenderer.on('aria:state', (_e, state) => cb(state)),
  onSongs: (cb) => ipcRenderer.on('aria:songs', (_e, payload) => cb(payload)),
  onData: (cb) => ipcRenderer.on('aria:data', (_e, payload) => cb(payload)),
  onToast: (cb) => ipcRenderer.on('aria:toast', (_e, toast) => cb(toast)),
  // Ricerca rapida
  search: (q) => ipcRenderer.invoke('aria:search', q),
  paletteCmd: (name, arg) => ipcRenderer.send('aria:palette-cmd', name, arg),
  onPaletteOpen: (cb) => ipcRenderer.on('aria:palette-open', () => cb()),
});
