// Iniettato in music.apple.com: segue MusicKit e riceve i comandi dall'app.
(() => {
  if (window.__aria) return;
  const send = (type, payload) => window.ariaBridge && window.ariaBridge.send(type, payload);
  let mk = null;

  const artUrl = (item, size) => {
    const art = item.artwork || (item.attributes && item.attributes.artwork);
    if (!art || !art.url) return null;
    return art.url.replace('{w}', size).replace('{h}', size).replace('{f}', 'jpg').replace('{c}', '');
  };

  const track = () => {
    const it = mk.nowPlayingItem;
    if (!it) return null;
    const attrs = it.attributes || {};
    const art = attrs.artwork || it.artwork || {};
    return {
      id: it.id,
      title: it.title || attrs.name || '',
      artist: it.artistName || attrs.artistName || '',
      album: it.albumName || attrs.albumName || '',
      art: artUrl(it, 600),
      color: art.bgColor || null,
      genre: (attrs.genreNames && attrs.genreNames.find((g) => g !== 'Musica' && g !== 'Music')) || (attrs.genreNames || [])[0] || '',
    };
  };

  const playback = () => ({
    playing: !!mk.isPlaying,
    time: mk.currentPlaybackTime || 0,
    duration: mk.currentPlaybackDuration || 0,
  });

  // ---------- Audio ----------
  const audio = { fadeMs: 0, sinkLabel: '', pauseOnUnplug: true };
  let fadeState = null; // dissolvenza del timer di spegnimento in corso
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Il lettore audio di MusicKit non è nella pagina: lo si intercetta quando parte, per scegliere l'uscita
  const mediaEls = new Set();
  const origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function (...args) {
    if (this.tagName === 'AUDIO' || !this.muted) { mediaEls.add(this); applySink(this); }
    return origPlay.apply(this, args);
  };
  async function sinkId() {
    if (!audio.sinkLabel) return 'default';
    const devs = await navigator.mediaDevices.enumerateDevices();
    const d = devs.find((x) => x.kind === 'audiooutput' && x.label === audio.sinkLabel);
    return d ? d.deviceId : 'default';
  }
  async function applySink(el) {
    try {
      const id = await sinkId();
      if (el.sinkId !== id) await el.setSinkId(id);
    } catch {}
  }
  async function sendDevices() {
    try {
      const devs = await navigator.mediaDevices.enumerateDevices();
      const outs = devs.filter((d) => d.kind === 'audiooutput' && d.deviceId !== 'default' && d.deviceId !== 'communications').map((d) => d.label);
      send('devices', outs);
      return outs;
    } catch { return []; }
  }
  // Cuffie scollegate: se spariscono uscite audio durante la riproduzione, pausa
  let outputCount = null;
  navigator.mediaDevices.addEventListener('devicechange', async () => {
    const outs = await sendDevices();
    if (audio.pauseOnUnplug && mk && mk.isPlaying && outputCount !== null && outs.length < outputCount) mk.pause();
    outputCount = outs.length;
    mediaEls.forEach(applySink);
  });

  // Dissolvenza del volume su play/pausa comandati da Beats
  async function fadeTo(target, ms) {
    const from = mk.volume, steps = Math.max(1, Math.round(ms / 25));
    for (let i = 1; i <= steps; i++) { mk.volume = from + (target - from) * (i / steps); await sleep(ms / steps); }
  }
  async function playPause() {
    if (!audio.fadeMs) return mk.isPlaying ? mk.pause() : mk.play();
    if (mk.isPlaying) {
      const vol = mk.volume;
      await fadeTo(0, audio.fadeMs);
      await mk.pause();
      mk.volume = vol;
    } else {
      const vol = mk.volume;
      mk.volume = 0;
      await mk.play();
      await fadeTo(vol, audio.fadeMs);
    }
  }

  window.__aria = {
    audio(opts) {
      Object.assign(audio, { fadeMs: opts.fadeMs, sinkLabel: opts.sinkLabel, pauseOnUnplug: opts.pauseOnUnplug });
      if (!mk) return;
      mk.bitrate = opts.quality === 'standard' ? MusicKit.PlaybackBitrate.STANDARD : MusicKit.PlaybackBitrate.HIGH;
      try { mk.autoplayEnabled = !!opts.autoplay; } catch {}
      mediaEls.forEach(applySink);
    },
    setVolume(v) { if (mk) mk.volume = v; },

    // Timer di spegnimento: abbassa piano il volume, mette in pausa e rimette il volume di prima
    async fadeOutAndPause(ms) {
      if (!mk || fadeState) return;
      fadeState = { vol: mk.volume, cancelled: false };
      const steps = Math.max(1, Math.round(ms / 100));
      for (let i = 1; i <= steps && !fadeState.cancelled; i++) {
        mk.volume = fadeState.vol * (1 - i / steps);
        await sleep(ms / steps);
      }
      if (!fadeState.cancelled) await mk.pause();
      mk.volume = fadeState.vol;
      fadeState = null;
    },
    cancelFade() { if (fadeState) fadeState.cancelled = true; },

    // Preferito ("cuore") per il brano in ascolto
    async love() {
      const it = mk && mk.nowPlayingItem;
      if (!it) return 'nessuno';
      const pp = (it.attributes && it.attributes.playParams) || it.playParams || {};
      const id = pp.catalogId || (String(it.id).startsWith('i.') ? null : it.id);
      if (!id) return 'non-catalogo';
      try {
        await mk.api.music(`/v1/me/favorites`, { 'ids[songs]': id }, { fetchOptions: { method: 'POST' } });
      } catch {
        await mk.api.music(`/v1/me/ratings/songs/${id}`, {}, {
          fetchOptions: { method: 'PUT', body: JSON.stringify({ type: 'rating', attributes: { value: 1 } }) },
        });
      }
      return it.title;
    },

    // Ricerca rapida: catalogo Apple Music + la tua libreria
    async search(q) {
      const sf = mk.storefrontId || 'it';
      const pick = (r) => (r.status === 'fulfilled' ? r.value.data.results || {} : {});
      const [cat, lib] = await Promise.allSettled([
        mk.api.music(`/v1/catalog/${sf}/search`, { term: q, types: 'songs,albums,artists,playlists', limit: 4 }),
        mk.api.music('/v1/me/library/search', { term: q, types: 'library-songs,library-albums,library-playlists', limit: 3 }),
      ]);
      const out = [];
      const add = (group, kind, label, source) => {
        for (const d of (group && group.data) || []) {
          const a = d.attributes || {};
          out.push({
            kind, label, source, id: d.id, type: d.type,
            title: a.name || '',
            subtitle: a.artistName || a.curatorName || (kind === 'artist' ? 'Artista' : ''),
            art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 96).replace('{h}', 96).replace('{f}', 'jpg') : '',
            url: a.url || '',
          });
        }
      };
      const l = pick(lib), c = pick(cat);
      add(l['library-songs'], 'song', 'Brano', 'Libreria');
      add(l['library-albums'], 'album', 'Album', 'Libreria');
      add(l['library-playlists'], 'playlist', 'Playlist', 'Libreria');
      add(c.songs, 'song', 'Brano', 'Apple Music');
      add(c.albums, 'album', 'Album', 'Apple Music');
      add(c.artists, 'artist', 'Artista', 'Apple Music');
      add(c.playlists, 'playlist', 'Playlist', 'Apple Music');
      return out;
    },
    async playItem(kind, id) {
      const key = { song: 'song', album: 'album', playlist: 'playlist' }[kind];
      if (key) await mk.setQueue({ [key]: id, startPlaying: true });
    },

    // Libreria per le viste di Beats: album dal più recente aggiunto, artisti con i loro id
    async libraryAlbums() {
      const page = (offset) => mk.api.music('/v1/me/library/albums', { limit: 100, offset, sort: '-dateAdded' });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      return pages.flatMap((p) => p.data.data).map((d) => {
        const a = d.attributes || {};
        return {
          id: d.id, title: a.name || '', artist: a.artistName || '', count: a.trackCount || 0,
          art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 300).replace('{h}', 300).replace('{f}', 'jpg') : '',
        };
      });
    },
    async libraryArtists() {
      const out = [];
      for (let offset = 0; offset < 5000; offset += 100) {
        const r = await mk.api.music('/v1/me/library/artists', { limit: 100, offset });
        out.push(...r.data.data.map((d) => ({ id: d.id, name: (d.attributes && d.attributes.name) || '' })));
        if (!r.data.next) break;
      }
      return out;
    },
    // Layout del lettore grande a schermo intero (copertina sfumata al centro, testi a destra)
    setFs(on) {
      fsOn = !!on;
      document.documentElement.classList.toggle('beats-fs', fsOn);
      paintFsButton();
      requestAnimationFrame(() => requestAnimationFrame(placeQueueButton));
      setTimeout(placeQueueButton, 500);
    },
    outputs() { return [...mediaEls].map((e) => `${e.tagName}:${e.sinkId || 'default'}`); }, // diagnostica
    cmd(name, arg) {
      if (!mk) return;
      switch (name) {
        case 'playPause': playPause(); break;
        case 'next': mk.skipToNextItem(); break;
        case 'prev': mk.currentPlaybackTime > 3 ? mk.seekToTime(0) : mk.skipToPreviousItem(); break;
        case 'seek': if (mk.currentPlaybackDuration) mk.seekToTime(arg * mk.currentPlaybackDuration); break;
      }
    },
    // Tutti i brani della libreria, dal più recente aggiunto (ordine fornito dal server di Apple)
    async librarySongs() {
      const page = (offset) => mk.api.music('/v1/me/library/songs', { limit: 100, offset, sort: '-dateAdded' });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      const songs = [];
      for (const p of pages) {
        for (const s of p.data.data) {
          const a = s.attributes || {};
          songs.push({
            id: s.id,
            title: a.name || '',
            artist: a.artistName || '',
            album: a.albumName || '',
            ms: a.durationInMillis || 0,
            art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 80).replace('{h}', 80).replace('{f}', 'jpg') : null,
          });
        }
      }
      return songs;
    },
    async playSongs(ids, shuffle) {
      mk.shuffleMode = shuffle ? 1 : 0;
      await mk.setQueue({ songs: ids, startPlaying: true });
    },
    style(s) {
      const root = document.documentElement;
      const set = (k, v) => root.style.setProperty(k, v);
      set('--aria-accent', s.accent);
      set('--aria-nav-alpha', s.navAlpha);
      set('--aria-player-alpha', s.playerAlpha);
      set('--aria-radius', s.radius + 'px');
      set('--beats-radius', s.uiRadius + 'px');
      set('--beats-shadow', s.shadow);
      set('--beats-glass-alpha', s.glassAlpha);
      set('--beats-glass-blur', s.glassBlur + 'px');
      const icon = { white: ['#fff', '#1c1c1e'], accent: [s.accent, s.accent], muted: ['rgba(255,255,255,0.55)', 'rgba(0,0,0,0.5)'] }[s.navIcon];
      set('--beats-nav-icon', icon[0]);
      set('--beats-nav-icon-light', icon[1]);
      root.dataset.ariaFont = s.font;
      root.dataset.ariaHoverZoom = s.hoverZoom ? 'on' : 'off';
      root.classList.toggle('beats-glass', s.glassBlur > 0);
      root.classList.toggle('beats-lite-bg', s.liteBg);
      root.classList.toggle('beats-nolyrics', !s.showLyrics);
      root.dataset.viz = s.visualizer;
      requestAnimationFrame(() => requestAnimationFrame(placeQueueButton)); // la colonna dei comandi si sposta
      root.style.fontFamily = '';
      if (s.customFont) set('--beats-custom-font', `"${s.customFont.replace(/["\\]/g, '')}"`);
      root.classList.toggle('beats-custom-font', !!s.customFont);
      paintLyricsButton(s.showLyrics);
      let tag = document.getElementById('beats-user-css');
      if (!tag) { tag = document.createElement('style'); tag.id = 'beats-user-css'; document.head.append(tag); }
      if (tag.textContent !== s.customCss) tag.textContent = s.customCss;
    },
  };

  const hook = () => {
    try { mk = MusicKit.getInstance(); } catch { mk = null; }
    if (!mk) return setTimeout(hook, 500);
    send('ready', true);
    sendDevices().then((outs) => { outputCount = outs.length; });
    send('track', track());
    send('playback', playback());
    mk.addEventListener('nowPlayingItemDidChange', () => { send('track', track()); refreshIfOpen(); paintFsBackground(); });
    mk.addEventListener('queueItemsDidChange', refreshIfOpen);
    mk.addEventListener('queuePositionDidChange', refreshIfOpen);
    mk.addEventListener('playbackStateDidChange', () => {
      send('playback', playback());
      document.documentElement.classList.toggle('beats-playing', !!mk.isPlaying);
    });
    let last = 0;
    mk.addEventListener('playbackTimeDidChange', () => {
      const now = Date.now();
      if (now - last > 900) { last = now; send('playback', playback()); }
    });
  };

  // ---------- Coda e cronologia nel lettore grande ----------
  const Q = { open: false, tab: 'next', recent: [], recentAt: 0 };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const info = (it) => {
    const a = it.attributes || {};
    const art = it.artwork || a.artwork;
    return {
      id: it.id,
      title: it.title || a.name || '',
      artist: it.artistName || a.artistName || '',
      art: art && art.url ? art.url.replace('{w}', 80).replace('{h}', 80).replace('{f}', 'jpg').replace('{c}', '') : '',
    };
  };
  const ICON = {
    queue: '<svg viewBox="0 0 24 24"><path d="M3 6h12M3 11h12M3 16h7"/><path d="M17 13v7.5"/><circle cx="15" cy="20" r="2"/><path d="M17 13l4-1.5"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M4 7h10M4 12h10M4 17h6"/><path d="M18 20V9M15 12l3-3 3 3"/></svg>',
    last: '<svg viewBox="0 0 24 24"><path d="M4 7h10M4 12h10M4 17h6"/><path d="M18 9v11M15 17l3 3 3-3"/></svg>',
    remove: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    lyrics: '<svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/></svg>',
    expand: '<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    shrink: '<svg viewBox="0 0 24 24"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>',
  };
  let fsOn = false;

  async function loadRecent(force) {
    if (!force && Date.now() - Q.recentAt < 60000) return;
    try {
      const r = await mk.api.music('/v1/me/recent/played/tracks', { limit: 30 });
      Q.recent = r.data.data.map(info);
      Q.recentAt = Date.now();
    } catch {}
  }

  // Riproduce subito un brano che non è nella coda: lo mette dopo quello attuale e ci salta
  async function playNow(id) {
    if (!mk.queue.length) return mk.setQueue({ songs: [id], startPlaying: true });
    await mk.playNext({ songs: [id] });
    await mk.skipToNextItem();
  }

  // Sposta un brano tra i prossimi (indici della coda); quelli già ascoltati e l'attuale non si toccano
  function moveInQueue(from, to) {
    const pos = mk.queue.position;
    if (from <= pos || to <= pos || from === to) return;
    const moved = mk.queue.spliceQueueItems(from, 1, []);
    mk.queue.spliceQueueItems(to, 0, moved);
  }

  async function queueAction(act, idx, id) {
    try {
      const pos = mk.queue.position;
      if (act === 'jump') await mk.changeToMediaAtIndex(idx);
      else if (act === 'remove') mk.queue.remove(idx);
      else if (act === 'up') moveInQueue(idx, pos + 1); // subito dopo il brano attuale
      else if (act === 'move') moveInQueue(idx, id);
      else if (act === 'now') await playNow(id);
      else if (act === 'after') await mk.playNext({ songs: [id] });
      else if (act === 'later') await mk.playLater({ songs: [id] });
    } catch (e) { console.warn('coda', e); }
    renderQueue();
  }

  function row(it, actions, opts = {}) {
    const btns = actions.map(([act, icon, title]) => `<button data-act="${act}" title="${title}">${ICON[icon]}</button>`).join('');
    return `<li class="${opts.now ? 'now' : ''}${opts.sortable ? ' up' : ''}" data-idx="${opts.idx ?? ''}" data-id="${esc(it.id)}">
      ${opts.sortable ? '<span class="grip" title="Trascina per spostare"><i></i><i></i><i></i></span>' : ''}
      ${it.art ? `<img src="${esc(it.art)}" alt="" draggable="false">` : '<span class="ph"></span>'}
      <div class="tx"><b>${esc(it.title)}</b><span>${esc(it.artist)}</span></div>
      <div class="ac">${btns}</div></li>`;
  }

  let drag = null;            // brano che si sta trascinando nella coda
  let renderAfterDrag = false;
  async function renderQueue() {
    const panel = document.getElementById('beats-queue');
    if (!panel || !mk) return;
    if (drag && drag.active) { renderAfterDrag = true; return; } // non ridisegnare sotto il dito
    panel.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === Q.tab));
    const list = panel.querySelector('ol');
    const items = mk.queue.items || [];
    const pos = mk.queue.position;
    let html = '';
    if (Q.tab === 'next') {
      if (items[pos]) html += `<h4>In riproduzione</h4>` + row(info(items[pos]), [], { now: true, idx: pos });
      const upcoming = items.map((it, i) => [it, i]).filter(([, i]) => i > pos);
      html += `<h4>Prossimi · ${upcoming.length}</h4>`;
      html += upcoming.map(([it, i]) => row(info(it), [['jump', 'play', 'Riproduci ora'], ['up', 'next', 'Sposta subito dopo'], ['remove', 'remove', 'Togli dalla coda']], { idx: i, sortable: true })).join('')
        || '<p class="empty">Nessun brano in coda dopo questo.</p>';
    } else {
      const played = items.map((it, i) => [it, i]).filter(([, i]) => i < pos).reverse();
      if (played.length) {
        html += `<h4>In questa sessione</h4>`;
        html += played.map(([it, i]) => row(info(it), [['jump', 'play', 'Riascolta ora'], ['after', 'next', 'Riproduci subito dopo'], ['later', 'last', 'Riproduci per ultimo']], { idx: i })).join('');
      }
      await loadRecent();
      html += `<h4>Ascoltati di recente</h4>`;
      html += Q.recent.map((it) => row(it, [['now', 'play', 'Riproduci ora'], ['after', 'next', 'Riproduci subito dopo'], ['later', 'last', 'Riproduci per ultimo']])).join('')
        || '<p class="empty">Nessun ascolto recente.</p>';
    }
    list.innerHTML = html;
  }

  function placeQueueButton() {
    const btn = document.getElementById('beats-queue-btn');
    const controls = document.querySelector('[data-testid="lyrics-fullscreen-modal"] apple-music-playback-controls');
    if (!btn || !controls) return;
    const fs = document.getElementById('beats-fs-btn');
    const ly = document.getElementById('beats-lyrics-btn');
    // A schermo intero i pulsanti di Beats stanno in fondo alla barra dei comandi
    const bar = fsOn && document.querySelector('[data-testid="lyrics-fullscreen-modal"] .lyrics__controls');
    if (bar) {
      const b = bar.getBoundingClientRect();
      const top = `${Math.round(b.top + b.height / 2 - 16)}px`;
      [[ly, 140], [btn, 98], [fs, 56]].forEach(([el, off]) => { if (el) { el.style.left = `${Math.round(b.right - off)}px`; el.style.top = top; } });
      return;
    }
    const r = controls.getBoundingClientRect();
    // Allinea al centro dei pulsanti veri (play, avanti...), anche se stanno in una shadow root
    const root = controls.shadowRoot || controls;
    const rects = [...root.querySelectorAll('button')].map((b) => b.getBoundingClientRect()).filter((b) => b.width > 0);
    const right = r.right; // alcuni pulsanti stanno in shadow root annidate: il bordo destro lo dà il contenitore
    const mid = rects.length ? rects.reduce((s, b) => s + b.top + b.height / 2, 0) / rects.length : r.top + r.height / 2;
    btn.style.left = `${Math.round(right + 14)}px`;
    btn.style.top = `${Math.round(mid - 19)}px`;
    if (fs) { fs.style.left = `${Math.round(right + 60)}px`; fs.style.top = btn.style.top; }
    if (ly) { ly.style.left = `${Math.round(right + 106)}px`; ly.style.top = btn.style.top; }
  }

  let lyricsOn = true;
  function paintLyricsButton(on) {
    lyricsOn = on;
    const b = document.getElementById('beats-lyrics-btn');
    if (!b) return;
    b.innerHTML = ICON.lyrics;
    b.classList.toggle('on', on);
    b.title = on ? 'Nascondi il testo' : 'Mostra il testo';
  }

  // Sfondo leggero: la copertina attuale, sfocata dal CSS una volta sola
  function paintFsBackground() {
    const bg = document.getElementById('beats-fs-bg');
    const it = mk && mk.nowPlayingItem;
    if (!bg || !it) return;
    const art = info(it).art.replace('80x80', '400x400');
    if (art) bg.style.backgroundImage = `url("${art}")`;
  }

  function paintFsButton() {
    const fs = document.getElementById('beats-fs-btn');
    if (!fs) return;
    fs.innerHTML = fsOn ? ICON.shrink : ICON.expand;
    fs.title = fsOn ? 'Esci dallo schermo intero (Esc)' : 'Schermo intero senza bordi';
    fs.classList.toggle('on', fsOn);
  }

  function setupQueueUi(modal) {
    if (document.getElementById('beats-queue-btn')) return;
    const btn = document.createElement('button');
    btn.id = 'beats-queue-btn';
    btn.title = 'Coda e cronologia';
    btn.innerHTML = ICON.queue;
    const panel = document.createElement('aside');
    panel.id = 'beats-queue';
    panel.innerHTML = `<header><div class="tabs"><button data-tab="next">Coda</button><button data-tab="history">Cronologia</button></div>
      <button class="x" title="Chiudi">${ICON.remove}</button></header><ol></ol>`;
    const fsBtn = document.createElement('button');
    fsBtn.id = 'beats-fs-btn';
    fsBtn.onclick = (e) => { e.stopPropagation(); send('fsToggle', true); };
    const lyBtn = document.createElement('button');
    lyBtn.id = 'beats-lyrics-btn';
    // Con la coda aperta il pulsante del testo rigira la carta sul testo; altrimenti mostra/nasconde il testo
    lyBtn.onclick = (e) => {
      e.stopPropagation();
      if (Q.open && fsOn) { toggle(false); if (!lyricsOn) send('lyricsToggle', true); }
      else send('lyricsToggle', true);
    };
    const bg = document.createElement('div');
    bg.id = 'beats-fs-bg';
    // Visualizzatore "finto" (l'audio protetto non si può analizzare): barre e bagliore animati solo con CSS
    const viz = document.createElement('div');
    viz.id = 'beats-viz';
    viz.innerHTML = Array.from({ length: 48 }, (_, i) => {
      const d = (0.55 + ((i * 37) % 23) / 25).toFixed(2), delay = (-((i * 53) % 17) / 10).toFixed(2);
      return `<i style="--d:${d}s;--delay:${delay}s;--h:${(0.35 + ((i * 29) % 13) / 20).toFixed(2)}"></i>`;
    }).join('');
    const glow = document.createElement('div');
    glow.id = 'beats-glow';
    modal.prepend(bg, glow, viz);
    modal.append(lyBtn, btn, fsBtn, panel);
    paintFsButton();
    paintLyricsButton(lyricsOn);
    paintFsBackground();

    const toggle = (open) => {
      Q.open = open;
      panel.classList.toggle('open', open);
      btn.classList.toggle('on', open);
      document.documentElement.classList.toggle('beats-queue-open', open);
      if (open) { loadRecent(true).then(renderQueue); renderQueue(); }
    };
    btn.onclick = (e) => { e.stopPropagation(); toggle(!Q.open); };
    panel.querySelector('.x').onclick = () => toggle(false);
    panel.querySelector('.tabs').onclick = (e) => {
      const t = e.target.closest('[data-tab]');
      if (t) { Q.tab = t.dataset.tab; renderQueue(); }
    };
    // Trascinamento dei prossimi brani: la riga segue il puntatore, le altre si scostano per farle posto
    const list = panel.querySelector('ol');
    let suppressClick = false;
    list.addEventListener('pointerdown', (e) => {
      const li = e.target.closest('li.up');
      if (!li || e.button !== 0 || e.target.closest('button')) return;
      const rows = [...list.querySelectorAll('li.up')];
      const rects = rows.map((r) => r.getBoundingClientRect());
      drag = {
        li, rows, from: rows.indexOf(li), to: rows.indexOf(li), startY: e.clientY, startScroll: list.scrollTop,
        rowH: rects.length > 1 ? rects[1].top - rects[0].top : rects[0].height, active: false, id: e.pointerId,
      };
    });
    list.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dy = e.clientY - drag.startY + (list.scrollTop - drag.startScroll);
      if (!drag.active) {
        if (Math.abs(dy) < 6) return;
        drag.active = true;
        drag.li.setPointerCapture(e.pointerId);
        drag.li.classList.add('dragging');
        list.classList.add('sorting');
      }
      drag.li.style.transform = `translate3d(0, ${dy}px, 0) scale(1.02)`;
      const to = Math.max(0, Math.min(drag.rows.length - 1, drag.from + Math.round(dy / drag.rowH)));
      if (to !== drag.to) {
        drag.to = to;
        drag.rows.forEach((r, k) => {
          if (r === drag.li) return;
          let shift = 0;
          if (drag.from < to && k > drag.from && k <= to) shift = -drag.rowH;
          if (drag.from > to && k >= to && k < drag.from) shift = drag.rowH;
          r.style.transform = shift ? `translate3d(0, ${shift}px, 0)` : '';
        });
      }
      // Vicino ai bordi la lista scorre da sola
      const box = list.getBoundingClientRect();
      if (e.clientY < box.top + 50) list.scrollTop -= 12;
      else if (e.clientY > box.bottom - 50) list.scrollTop += 12;
    });
    const endDrag = () => {
      if (!drag) return;
      const d = drag;
      drag = null;
      if (!d.active) return;
      suppressClick = true;
      setTimeout(() => { suppressClick = false; }, 50);
      list.classList.remove('sorting');
      d.li.classList.remove('dragging');
      d.rows.forEach((r) => { r.style.transform = ''; });
      if (d.to !== d.from) queueAction('move', +d.li.dataset.idx, +d.rows[d.to].dataset.idx);
      else if (renderAfterDrag) renderQueue();
      renderAfterDrag = false;
    };
    list.addEventListener('pointerup', endDrag);
    list.addEventListener('pointercancel', endDrag);

    list.onclick = (e) => {
      if (suppressClick) return;
      const b = e.target.closest('button[data-act]');
      const li = e.target.closest('li');
      if (!li) return;
      const idx = li.dataset.idx === '' ? -1 : +li.dataset.idx;
      if (b) return queueAction(b.dataset.act, idx, li.dataset.id);
      // clic sulla riga: riproduci
      if (li.classList.contains('now')) return;
      queueAction(idx >= 0 ? 'jump' : 'now', idx, li.dataset.id);
    };
    const controls = modal.querySelector('apple-music-playback-controls');
    if (controls) new ResizeObserver(placeQueueButton).observe(controls);
    placeQueueButton();
    setTimeout(placeQueueButton, 400);
    if (Q.open) toggle(true);
  }
  window.addEventListener('resize', placeQueueButton);
  // A schermo intero Esc riporta in finestra: lo si intercetta prima di Apple, che chiude il lettore
  // al rilascio del tasto (keyup sul body). Va quindi fermato anche il keyup che segue.
  let swallowEscUp = false;
  window.addEventListener('keydown', (e) => {
    if (fsOn && e.key === 'Escape') {
      e.preventDefault();
      e.stopImmediatePropagation();
      swallowEscUp = true;
      send('fsExit', true);
    }
  }, true);
  window.addEventListener('keyup', (e) => {
    if (e.key === 'Escape' && (swallowEscUp || fsOn)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      swallowEscUp = false;
    }
  }, true);
  const refreshIfOpen = () => { if (Q.open) renderQueue(); };

  // Lettore a schermo intero di Apple (clic sulla copertina nel player): avvisa l'app per il vero schermo intero
  let fullOpen = false;
  new MutationObserver(() => {
    const modal = document.querySelector('[data-testid="lyrics-fullscreen-modal"]');
    const open = !!modal;
    if (open) setupQueueUi(modal);
    if (open !== fullOpen) { fullOpen = open; send('fullplayer', open); }
  }).observe(document.body, { childList: true, subtree: true });

  const wait = () => (window.MusicKit && MusicKit.getInstance ? hook() : setTimeout(wait, 400));
  wait();
})();
